import {lazy} from 'react';

const Login = lazy(() => import('../container/login'));
const ForgotPassword = lazy(() => import('../container/forgot-password'));
const Athletes = lazy(() => import('../container/athletes'));
const ExternalUsers = lazy(() => import('../container/externalUser'));
const Goals = lazy(() => import('../container/goals'));
const Highlights = lazy(() => import('../container/highlights'));
const Marketing = lazy(() => import('../container/marketing'));
const Branding = lazy(() => import('../container/branding'));
const Visionboard = lazy(() => import('../container/visionboard'));
const Legal = lazy(() => import('../container/legal'));
const Calendar = lazy(() => import('../container/calendar'));

const CreateOrEditAthletes = lazy(() => import('../components/AthletesComponents/CreateOrEditAthletes'));
const AthletesDashboard = lazy(() => import('../components/AthletesComponents/AthletesDashboard'));
const ViewCompletedGoals = lazy(() => import('../components/GoalsComponents/ViewCompletedGoals'));
const CreateOrEditMarketing = lazy(() => import('../components/MarketingComponents/CreateOrEditMarketing'));
const AddBranding = lazy(() => import('../components/BrandingComponents/AddBranding'));
const CreateOrEditHighlights = lazy(() => import('../components/HighlightsComponents/CreateOrEditHighlights'));
const CreateOrEditExternalUser = lazy(() => import('../components/ExternalUserComponents/CreateOrEditExternalUser'));
const AddLegal = lazy(() => import('../components/LegalComponents/AddLegal'));
const ViewOrDeleteLegal = lazy(() => import('../components/LegalComponents/ViewOrDeleteLegal'));
const CreateVisionboard = lazy(() => import('../components/VisionBoardComponents/CreateVisionBoard'));

const routes = [
    {
        path: '/login',
        exact: true,
        name: 'Login',
        component: Login,
        private: false
    },
    {
        path: '/forgot-password',
        exact: true,
        name: 'Forgot Password',
        component: ForgotPassword,
        private: false
    },
    //===== Athletes==============
    {
        path: '/athletes',
        exact: true,
        name: 'Athletes',
        component: Athletes,
        private: true
    },
    {
        path: '/athletes/create',
        exact: true,
        name: 'Athletes Create',
        component: CreateOrEditAthletes,
        private: true
    },
    {
        path: '/athletes/:id/edit',
        exact: true,
        name: 'Athletes Edit',
        component: CreateOrEditAthletes,
        private: true
    },
    {
        path: '/athletes/dashboard/:id',
        exact: true,
        name: 'Athletes Dashboard',
        component: AthletesDashboard,
        private: true
    },
    {
        path: '/dashboard',
        exact: true,
        name: 'Athlete Dashboard',
        component: AthletesDashboard,
        private: true
    },
    //===== External User==============
    {
        path: '/externals',
        exact: true,
        name: 'External User',
        component: ExternalUsers,
        private: true
    },
    {
        path: '/externals/create',
        exact: true,
        name: 'ExternalUser Create',
        component: CreateOrEditExternalUser,
        private: true
    },
    {
        path: '/externals/:id/edit',
        exact: true,
        name: 'ExternalUser Edit',
        component: CreateOrEditExternalUser,
        private: true
    },
    //======== External User==========
    //===== Goals==============
    {
        path: '/goals',
        exact: true,
        name: 'Goals',
        component: Goals,
        private: true
    },
    {
        path: '/goals/goals-completed',
        exact: true,
        name: 'Goals Completed',
        component: ViewCompletedGoals,
        private: true
    },
    //=====Goals==============
    //=====HighLight==============
    {
        path: '/highlights',
        exact: true,
        name: 'Highlights',
        component: Highlights,
        private: true
    },
    {
        path: '/highlights/create',
        exact: true,
        name: 'Highlights Create Or Edit',
        component: CreateOrEditHighlights,
        private: true
    },
    {
        path: '/highlights/:id/view',
        exact: true,
        name: 'Highlights Create Or Edit',
        component: CreateOrEditHighlights,
        private: true
    },
    {
        path: '/highlights/:id/edit',
        exact: true,
        name: 'Highlights Create Or Edit',
        component: CreateOrEditHighlights,
        private: true
    },
    //========== Marketing ==========
    {
        path: '/marketing',
        exact: true,
        name: 'Marketing',
        component: Marketing,
        private: true
    },
    {
        path: '/marketing/create',
        exact: true,
        name: 'Marketing Add',
        component: CreateOrEditMarketing,
        private: true
    },
    {
        path: '/marketing/:id/view',
        exact: true,
        name: 'Marketing Edit',
        component: CreateOrEditMarketing,
        private: true
    },
    {
        path: '/marketing/:id/edit',
        exact: true,
        name: 'Marketing Edit',
        component: CreateOrEditMarketing,
        private: true
    },
    //=============== Branding =================
    {
        path: '/branding',
        exact: true,
        name: 'Branding',
        component: Branding,
        private: true
    },
    {
        path: '/branding/create',
        exact: true,
        name: 'Branding Create',
        component: AddBranding,
        private: true
    },
    //=============================================
    {
        path: '/visionboard',
        exact: true,
        name: 'Visionboard',
        component: Visionboard,
        private: true
    },
    {
        path: '/visionboard/create',
        exact: true,
        name: 'Visionboard',
        component: CreateVisionboard,
        private: true
    },
    //======== Legal ========
    {
        path: '/legal',
        exact: true,
        name: 'Legal',
        component: Legal,
        private: true
    },
    {
        path: '/legal/upload',
        exact: true,
        name: 'Legal Add',
        component: AddLegal,
        private: true
    },
    {
        path: '/legal/view/:id',
        exact: true,
        name: 'View Legal',
        component: ViewOrDeleteLegal,
        private: true
    },
    {
        path: '/calender',
        exact: true,
        name: 'Calendar',
        component: Calendar,
        private: true
    },

];

export default routes;

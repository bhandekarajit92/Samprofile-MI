import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';
import { Link } from "react-router-dom";

import { Banner, DropDown, Loader } from "../components/CommonComponents";
import {getMarketingList, resetMarketingDetail} from "../redux/action";
import {getUser, orderList} from "../utils/helper";

const Marketing = props => {

    const [athleteList, setAthleteList] = useState([]);
    const [params, setParams] = useState({
        show_docs_for: '',
        order_by: ''
    });

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Marketing.loading);
    const marketingList = useSelector(state => state.Marketing.marketingList);

    useEffect(() => {
        if (marketingList && marketingList.athletes && marketingList.athletes.length > 0) {
            setAthleteList(marketingList.athletes.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [marketingList]);

    const onSelect = (e) => {
        setParams({
            ...params,
            [e.target.name]: e.target.value
        });
        dispatch(getMarketingList({...params, [e.target.name]: e.target.value}))
    };

    useEffect(() => {
        if(!JSON.parse(getUser()).is_admin) {
            setParams(prevState => ({
                ...prevState,
                show_docs_for: JSON.parse(getUser()).id
            }));
            dispatch(getMarketingList({
                show_docs_for: JSON.parse(getUser()).id
            }))
        } else {
            dispatch(getMarketingList({
                show_docs_for: '',
                order_by: ''
            }))
        }
    }, [dispatch]);

    return (
        <>
            {loading && <Loader/>}
            <div className="marketing">
                {
                    JSON.parse(getUser()).is_admin ?
                    <Banner
                        title='Marketing'
                        RedirectTo={`${props.match.url}/create`}
                        buttonText='Create new'
                        backClick={() => dispatch(resetMarketingDetail())}
                    />:
                    <Banner
                        title='Marketing'
                    />
                }
                <div className="centerContainer">
                    <div className="row justify-content-between pb-2">
                        <div className="col-md-6 col-12">
                            {
                                JSON.parse(getUser()).is_admin &&
                                <DropDown
                                    onselect={onSelect}
                                    dropDownHeading={<svg
                                        width="2em"
                                        height="2em"
                                        viewBox="0 0 16 16"
                                        className="bi bi-person-fill mb-2"
                                        fill="currentColor"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path fillRule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                    </svg>
                                    }
                                    dropDownSelected='All athletes'
                                    dropDownOption={athleteList}
                                    name='show_docs_for'
                                />
                            }
                        </div>
                        <div className="col-md-6 col-12 text-md-right">
                            <DropDown
                                onselect={onSelect}
                                dropDownHeading={<svg
                                    width="2em"
                                    height="2em"
                                    viewBox="0 0 16 16"
                                    className="bi bi-sort-up-alt mb-2"
                                    fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path fillRule="evenodd" d="M3 14a.5.5 0 0 0 .5-.5v-10a.5.5 0 0 0-1 0v10a.5.5 0 0 0 .5.5z"/>
                                    <path fillRule="evenodd" d="M5.354 5.854a.5.5 0 0 0 0-.708l-2-2a.5.5 0 0 0-.708 0l-2 2a.5.5 0 1 0 .708.708L3 4.207l1.646 1.647a.5.5 0 0 0 .708 0zM7 6.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5zm0 3a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 0-1h-5a.5.5 0 0 0-.5.5zm0 3a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 0-1h-7a.5.5 0 0 0-.5.5zm0-9a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0-.5.5z"/>
                                </svg>
                                }
                                dropDownSelected='Sort by'
                                dropDownOption={orderList}
                                name='order_by'
                            />
                        </div>
                    </div>
                    <div className="cardBox d-flex">
                        <div  className="row">
                            {
                                !loading && marketingList.documents && marketingList.documents.length > 0 ?
                                marketingList.documents.map((itm, key) =>
                                    <div className="market col-lg-3 col-md-4 col-6" key={key}>
                                        <Link
                                            to={JSON.parse(getUser()).is_admin ? `/marketing/${itm.id}/edit` : `/marketing/${itm.id}/view`}
                                            className="link"
                                        >
                                            <span className="label">{itm.created_for_name}</span>
                                            <img className='img-fluid' src='https://dev.samprofiles.com/images/card.jpg' alt="doc" />
                                            <p className="f-14">{itm.title}</p>
                                        </Link>
                                    </div>
                                )
                                    :
                                    marketingList.documents && marketingList.documents.length === 0 && <div className='f-18 py-5 px-3'>
                                        {
                                            JSON.parse(getUser()).is_admin ?
                                            'There are no marketing plans in here. Create one by clicking the "Create new" button in the top right corner.':
                                            'There are no marketing plans in here.'
                                        }
                                    </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

Marketing.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default Marketing;

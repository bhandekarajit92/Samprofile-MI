import React, { useState } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";

import { Banner } from "../components/CommonComponents";
import { CreateNewEvent } from "../components/CalanderComponents";

const Calendar = (props) => {
  const [isCreateNewEvent, setIsCreateNewEvent] = useState(false);

  const handleDateClick = (props) => {
    alert(props.dateStr);
  };

  return (
    <>
      <div className="calendar">
        <Banner
          title="Calendar"
          buttonText="Create new"
          isEvent={true}
          isGoal={true}
          setIsCreateNewEvent={setIsCreateNewEvent}
          classNames="min-width"
        />
        <CreateNewEvent
          isCreateNewEvent={isCreateNewEvent}
          setIsCreateNewEvent={setIsCreateNewEvent}
        />
        <div className="container-fluid pt-4">
          <div className="row">
            <div className="col col-lg-4 col-md-4 col-12 mb-3 p-3">
              <div className="events">
                <h3>
                  Pending events
                  <span className="count">0</span>
                </h3>
                <span className="pending">You have no pendings events..</span>
              </div>
            </div>
            <div className="col col-lg-8 col-md-8 col-12 pl-3 p-3 ">
              <div className="calendar-container">
                <FullCalendar
                  plugins={[dayGridPlugin]}
                  headerToolbar={{
                    start: "today prev next",
                    center: "title",
                    end: "dayGridMonth dayGridWeek dayGridDay",
                  }}
                  dateClick={handleDateClick}
                  initialView="dayGridMonth"
                  weekends={true}
                  events={[
                    { title: "event 1", date: "2020-09-01" },
                    { title: "event 2", date: "2020-09-02" },
                  ]}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Calendar;

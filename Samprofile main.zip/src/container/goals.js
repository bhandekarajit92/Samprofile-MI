import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";

import {Banner, Table, DateRangePickerCom, DeleteConfirmDialog, Loader} from "../components/CommonComponents";
import {CreateOrEditGoals, ViewGoalDetails} from "../components/GoalsComponents";
import {viewGoalsList, completedIncompletedGoal, deleteGoal} from "../redux/action";
import {getUser} from "../utils/helper";

const Goals = () => {
    const [isCreateOrEditGoalOpen, setCreateOrEditGoalOpen] = useState(false);
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [goalId, setGoalId] =  useState(null);
    const [goalEditId, setEditGoalId] =  useState(null);
    const [inCompletedGoalList, setIncompleteGoalList] = useState([]);
    const [isViewGoalOpen, setViewGoalOpen] = useState(false);
    const [data, setData] = useState({});

    const dispatch = useDispatch();

    const loading =useSelector(state => state.Goals.loading);
    const goalsData = useSelector(state => state.Goals.goalsList);

    useEffect(() => {
        dispatch(viewGoalsList());
    }, [dispatch]);

    useEffect(() => {
        if(goalsData && goalsData.length > 0) {
            setIncompleteGoalList(goalsData.filter(itm => !itm.completed));
        } else {
            setIncompleteGoalList([]);
        }
    }, [goalsData])

    const handleCheckEvent = (data) => {
        dispatch(completedIncompletedGoal({
            goal_id : data.id,
            completed : data.completed ? 0 : 1,
        }));
    };

    const handleDelete = () => {
        dispatch(deleteGoal({
            id: goalId,
            callBack: () => setDeleteOpen(false)
        }));
    };

    const  handleDateFilter = (data) => {
        dispatch(viewGoalsList(data))
    };

    return (
        <>
            {loading && <Loader/>}
            <div>
                <Banner
                    title='Your Goals'
                    buttonText='Create new'
                    count={goalsData && goalsData.filter(itm => itm.completed).length}
                    goalRedirect='/goals/goals-completed'
                    goalBannerText={goalsData && goalsData.filter(itm => itm.completed).length > 0 && 'View completed goals'}
                    isGoal={true}
                    setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                    classNames="min-width"
                />
                <div className="container-fluid goals">
                    <div className="row bg-white justify-content-lg-end pt-4 pb-3 m-lg-4 m-2">
                        <div className="col-lg-4 col-md-6 d-flex justify-content-lg-end justify-content-center align-self-center mb-lg-5 mb-0">
                            <DateRangePickerCom
                                handleDateFilter={handleDateFilter}
                            />
                        </div>
                        <div className="col-lg-2 mt-lg-0 mt-md-0 mt-3 col-md-6 d-flex justify-content-center mb-lg-5 mb-0 align-items-center pl-1">
                            <input className="customBtn f-14 text-white pl-2 pr-2" type="button" value="Export as PDF"/>
                        </div>
                        {
                            (!JSON.parse(getUser()).is_admin) &&
                            <div className="col-12 mt-3 mb-3">
                                <div className="time-stepper">
                                    {
                                        goalsData && goalsData.length > 0 &&
                                        goalsData.map((data, key) =>
                                            <div
                                                className="stepper-container cursor-pointer"
                                                onClick={() => {
                                                    setViewGoalOpen(true);
                                                    setData(data);
                                                }}
                                                key={key}
                                            >
                                                <div className="goal">
                                                    <div className="goal-title">
                                                        <div className="text-decoration-none f-24 cursor-pointer title-goal">{data.title}</div>
                                                        <div className="goal-start-date">Started {data.start_date_h}</div>
                                                    </div>
                                                    <div className="goal-tip"/>
                                                </div>
                                                <div className="goal-timeline"/>
                                                <div className="goal-timeline-circle"/>
                                                <div className="goal-due-date f-12">
                                                    {data.due_date_h}
                                                    {'\u00A0'}
                                                    <b>{data.due_date_time}</b>
                                                </div>
                                            </div>
                                        )
                                    }
                                    {/*Create goal button*/}
                                    <div className="stepper-container">
                                        <div className="goal" style={{width:'176px',textAlign: 'center !important', paddingLeft:'0'}}>
                                            <div className="text-center cursor-pointer" onClick={() => setCreateOrEditGoalOpen(true)}>
                                                <img src="https://dev.samprofiles.com/images/ic-add-circle.svg" width="26" height="26" alt={'img'} />
                                            </div>
                                            <div className="goal-title text-center cursor-pointer" onClick={() => setCreateOrEditGoalOpen(true)}>
                                                <p className="text-decoration-none f-22">Create</p>
                                            </div>
                                        </div>
                                        <div className="goal-tip invisible" />
                                        <div className="goal-timeline"/>
                                        <div className="goal-timeline-circle invisible"/>
                                        <div className="goal-due-date f-12 invisible">{`\u00A0`}</div>
                                    </div>
                                </div>
                            </div>
                        }
                    </div>
                    <Table
                        setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                        setDeleteOpen={setDeleteOpen}
                        tableData={inCompletedGoalList}
                        setGoalId={setGoalId}
                        setEditGoalId={setEditGoalId}
                        handleCheckEvent={handleCheckEvent}
                    />
                </div>
            </div>
            <CreateOrEditGoals
                isCreateOrEditGoalOpen={isCreateOrEditGoalOpen}
                setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                goalId={goalEditId}
                setGoalId={setEditGoalId}
            />
            <ViewGoalDetails
                isViewGoalOpen={isViewGoalOpen}
                setViewGoalOpen={setViewGoalOpen}
                data={data}
            />
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

export default Goals;
import React, {useState, Suspense, lazy, useEffect} from 'react';
import {Switch, useHistory, withRouter} from 'react-router-dom';

import { Loader } from "../components/CommonComponents";
import routes from '../routes/RoutesFile';
import PrivateRoute from "../routes/PrivateRoute";
import {getUser, useWindowSize} from "../utils/helper";

const Sidebar = lazy(() => import('./sidebar'));

const Main = React.memo((props) => {
    const [toggle, setToggle] = useState('0');
    const [width] = useWindowSize();

    const history = useHistory();

    useEffect(() => {
        if(width > 767) {
            setToggle('0');
        }
    }, [width]);

    useEffect(() => {
        if(getUser() && JSON.parse(getUser()).is_admin) {
            if(props.location.pathname === '/') {
                history.push('/athletes');
            }
        } else if(getUser() && !JSON.parse(getUser()).is_admin) {
            if(props.location.pathname === '/') {
                history.push('/dashboard');
            }
        }
    }, [history, props])

    return (
        <div className="dashboard">
            <Suspense fallback={<Loader/>}>
                <Sidebar
                    toggle={toggle}
                    setToggle={setToggle}
                />
            </Suspense>
            <div className='content-wrapper'>
                <span className="openBtn d-md-none">
                    <svg
                        width="1.5em"
                        height="1.5em"
                        viewBox="0 0 16 16"
                        className="bi bi-list"
                        fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        onClick={() => setToggle('1')}
                    >
                        <path fillRule="evenodd" d="M2.5 11.5A.5.5 0 0 1 3 11h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 7h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 3h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
                    </svg>
                </span>
                <Switch>
                    {routes.map((route, idx) => {
                        return route.component ?
                            <PrivateRoute
                                key={idx}
                                path={route.path}
                                exact={route.exact}
                                name={route.name}
                                component={route.component} />
                            : null;
                    })}
                </Switch>
            </div>
        </div>
    );
});

export default withRouter(Main);
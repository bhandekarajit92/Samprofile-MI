import React from 'react';
import PropTypes from 'prop-types';
import {NavLink, useHistory} from 'react-router-dom';
import {useDispatch} from 'react-redux';

import Logo from '../assets/images/logo.png';
import navigation from '../_navigation';
import {getUser, removeFolder, removeToken, removeUser} from "../utils/helper";
import {userDataRemove} from "../redux/action";

const Sidebar = ({toggle, setToggle}) => {
    const history = useHistory();
    const dispatch = useDispatch();
    return (
        <div className={
            toggle === '1' ? "side-wrapper side-active py-md-4" : toggle === '2' ? "side-wrapper inactive py-md-4" : "side-wrapper py-md-4"
        }>
            <div className="container side-bar">
                <div className="row">
                    <div className="col-12 text-right d-md-none text-white">
                        <svg
                            width="2em"
                            height="2em"
                            viewBox="0 0 16 16"
                            className="closebtn bi bi-x cursor-pointer"
                            fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg"
                            onClick={() => setToggle('2')}
                        >
                            <path fillRule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                        </svg>
                    </div>
                    <div className="col-12 text-center">
                        <div className="bor-btm pb-3">
                            <img src={Logo} className="img-fluid m-auto" alt="logo"/>
                        </div>
                    </div>
                    <div className="col-12">
                        <div className="nav flex-column nav-pills mt-5" id="v-pills-tab">
                            {
                                JSON.parse(getUser()).is_admin ?
                                    navigation &&
                                    navigation.items.filter(itm => (itm.type === 'admin' || itm.type === 'both')).map((itm, key) => <NavLink  onClick={() => setToggle('3')} to={itm.url}  className="links" activeClassName='active' key={key}>{itm.name}</NavLink>):
                                    navigation.items.filter(itm => (itm.type === 'athlete' || itm.type === 'both')).map((itm, key) => <NavLink onClick={() => setToggle('3')} to={itm.url}  className="links" activeClassName='active' key={key}>{itm.name}</NavLink>)
                            }
                            <span
                                className="links cursor-pointer"
                                onClick={() => {
                                    removeToken();
                                    dispatch(userDataRemove());
                                    history.push('/login');
                                    removeUser();
                                    removeFolder();
                                }}
                            >
                                Logout
                            </span>
                        </div>
                        {
                            !JSON.parse(getUser()).is_admin &&
                            <div className='athlete-portion'>
                                <p className='mt-3 font-weight-bolder'>Your Platforms</p>
                                <p className='f-14 font-weight-lighter pt-3 mb-0 website'>WEBSITE</p>
                                <p className='f-14 p-0'>{JSON.parse(getUser()).email}</p>
                            </div>
                        }
                    </div>
                </div>
            </div>
        </div>
    );
};

Sidebar.propTypes = {
    toggle: PropTypes.string,
    setToggle: PropTypes.func
};

export default Sidebar;

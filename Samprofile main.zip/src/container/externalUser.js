import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";
import PropTypes from 'prop-types';

import {Banner, ProfileCard, DeleteConfirmDialog, Loader} from '../components/CommonComponents';
import Avatar from '../assets/images/userImg.jpeg';
import {deleteUser, getUsersList, resetExternalUserDetail} from "../redux/action";
import {mediaUrl} from "../utils/helper";

const ExternalUser = props => {

    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] =  useState(null);

    const dispatch = useDispatch();

    const loading = useSelector(state => state.ExternalUser.loading);
    const usersList = useSelector(state => state.ExternalUser.usersList);

    useEffect(() => {
        dispatch(getUsersList());
    },[dispatch]);

    const handleDelete = () => {
        dispatch(deleteUser({
            id: deleteId,
            calBack: () => setDeleteOpen(false)
        }));
    };

    return (
        <>
            {loading && <Loader/>}
            <div className="external-user">
                <Banner
                    title='External users'
                    RedirectTo={`${props.match.url}/create`}
                    buttonText='Create new'
                    classNames="min-width"
                    backClick={() => dispatch(resetExternalUserDetail())}
                />
                <div className="cardContainer">
                    {
                        !loading && usersList && usersList.length > 0 ?
                            usersList.map((itm, key) =>
                                <ProfileCard
                                    userImage={
                                        itm.image ? `${mediaUrl}/avatar/${itm.image.filename}.${itm.image.extension}` :
                                            Avatar
                                    }
                                    userFirstName={itm.first_name}
                                    userLastName={itm.last_name}
                                    isAthlete={false}
                                    isEdit={true}
                                    isDelete={true}
                                    key={key}
                                    data={itm}
                                    setDeleteId={setDeleteId}
                                    isView={false}
                                    setDeleteOpen={setDeleteOpen}
                                />) :
                            usersList && usersList.length === 0 &&
                            <div className='f-24'>No record found</div>
                    }
                </div>
            </div>
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

ExternalUser.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default ExternalUser;

import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {Banner, DeleteConfirmDialog, Loader, ProfileCard} from '../components/CommonComponents';
import Avatar from '../assets/images/userImg.jpeg';
import {deleteAthlete, getAthletesList, resetAthleteDetail} from "../redux/action";
import {mediaUrl} from "../utils/helper";

const Athletes = (props) => {
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] = useState(null);

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Athlete.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);

    useEffect(() => {
        dispatch(getAthletesList());
    }, [dispatch]);

    const handleDelete = () => {
        dispatch(deleteAthlete({
            id: deleteId,
            calBack: () => setDeleteOpen(false)
        }));
    };

    return (
        <>
            {loading && <Loader/>}
            <div className="athletes">
                <Banner
                    title='Athletes'
                    RedirectTo={`${props.match.url}/create`}
                    buttonText='Create new'
                    backClick={() => dispatch(resetAthleteDetail())}
                />
                <div className="cardContainer">
                    {
                       athletesList && athletesList.length > 0 ?
                            athletesList.map((itm, key) =>
                                <ProfileCard
                                    userImage={
                                        itm.image ? `${mediaUrl}/avatar/${itm.image.filename}.${itm.image.extension}` :
                                        Avatar
                                    }
                                    userFirstName={itm.first_name}
                                    userLastName={itm.last_name}
                                    clubName={itm.current_club}
                                    isAthlete={true}
                                    isEdit={true}
                                    isDelete={true}
                                    isView={true}
                                    setDeleteOpen={setDeleteOpen}
                                    key={key}
                                    data={itm}
                                    setDeleteId={setDeleteId}
                                />
                            )
                            :
                           athletesList && athletesList.length === 0 &&
                           <div className='f-24'>
                               No record found
                           </div>
                    }
                </div>
            </div>
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

Athletes.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default Athletes;


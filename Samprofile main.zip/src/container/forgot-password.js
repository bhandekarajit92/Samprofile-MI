import React,{ useState } from 'react';
import validator from 'validator';
import {useDispatch, useSelector} from 'react-redux';

import {Input, Loader} from "../components/CommonComponents";
import validateForgotPassword from "../validations/forgotPassword";
import Logo from "../assets/images/login_logo.png";
import {forgotPassword} from "../redux/action";

const ForgotPassword = () => {
    const [email, setEmail] = useState('');
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        email: false
    });

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Login.loading);

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateForgotPassword({ email});
        setErrors(errors);
        if(isValid){
            dispatch(forgotPassword({
                email
            }))
        }
    };

    return (
        <>
            {loading && <Loader/>}
            <div className="flex-container row">
                <div className="flex-imgBox col-12 col-md-12 col-lg-6 col-xl-8">
                    <h1>Manage<br/>your<br/>arsenal</h1>
                </div>
                <div className="flex-loginBox col-12 col-md-12 col-lg-6 col-xl-4">
                    <div className="inner">
                        <div className="logo">
                            <img src={Logo} className='img-fluid' alt="logo"/>
                        </div>
                        <h2 className='mb-0 text-center'>Forgot password?</h2>
                        <form onSubmit={handleSubmit}>
                            <div  className='input'>
                                <Input
                                    type='email'
                                    placeholder='Email'
                                    name='email'
                                    className={errors.email ?
                                        'form-control is-invalid' : 'form-control'
                                    }
                                    value={email}
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                        setValid({ ...valid, email: validator.isEmail(e.target.value)})
                                        setErrors({ ...errors, email: false })
                                    }}
                                    errorMsg={errors && errors.email}
                                />
                            </div>
                            <div className='f-12 mt-1 text-secondary text-right'>
                                Send reset link to this email address
                            </div>
                            <div className="button">
                                <button
                                    type="submit"
                                    onClick={handleSubmit}
                                    className="btn border-0 rounded-0"
                                >
                                    Send
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ForgotPassword;
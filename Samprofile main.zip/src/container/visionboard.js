import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {Banner, DropDown, Loader} from "../components/CommonComponents";
import {getVisionboardList} from "../redux/action";
import {getUser, mediaUrl} from "../utils/helper";
import BlankImg from '../assets/images/annie-spratt-ctXf1GVyf9A-unsplash.png';

const Visionboard = () => {
    let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

    const [athleteList, setAthleteList] = useState([]);
    const [athlete_id, setAthleteId] = useState('');

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Visionboard.loading);
    const visionboardList = useSelector(state => state.Visionboard.visionboardList);

    useEffect(() => {
        if (visionboardList && visionboardList.athletes && visionboardList.athletes.length > 0) {
            setAthleteList(visionboardList.athletes.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [visionboardList]);

    useEffect(() => {
        dispatch(getVisionboardList({
            athlete_id,
        }))
    }, [dispatch, athlete_id]);


    const grid = (item,key) => {
        let classname = 'gallery__item gallery__item--'+item+' custom-border-dark mb-0';
        return (
            <figure className={classname}>
                <img className="gallery__img" src={ visionboardList  &&  visionboardList.visionBoard && visionboardList.visionBoard[key] ? `${mediaUrl}visionboard/${visionboardList.visionBoard[key].filename}.${visionboardList.visionBoard[key].extension}` : BlankImg} alt="img"/>
            </figure>
        )
    }


    return (
        <>
            {loading && <Loader/>}
            <div className="visionboard">
                {JSON.parse(getUser()).is_admin  ?
                    <Banner
                        title='Visionboard'
                    /> :
                    <Banner
                        title='Visionboard'
                        RedirectTo={`visionboard/create`}
                        buttonText='Upload new'
                        backClick={() => console.log('')}
                    />
                }
                <div className="container-fluid pl-0 pr-0">
                    {JSON.parse(getUser()).is_admin ? <div className='ml-3 mb-2'>
                                <DropDown
                                    onselect={(e) => {
                                        setAthleteId(e.target.value)
                                    }}
                                    dropDownHeading={<svg
                                        width="2em"
                                        height="2em"
                                        viewBox="0 0 16 16"
                                        className="bi bi-person-fill mb-2"
                                        fill="currentColor"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path fillRule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                    </svg>
                                    }
                                    dropDownSelected='Select athlete'
                                    dropDownOption={athleteList}
                                    name='athlete_id'
                                    value={athlete_id}
                                />
                            </div> : null }

                    <div className="gallery">
                        {arr.map((item,key)=>grid(item,key))}
                    </div>
                </div>
            </div>
        </>
    );
};

Visionboard.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default Visionboard;

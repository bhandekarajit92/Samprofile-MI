import React, {useEffect, useState} from 'react';
import {Link} from "react-router-dom";
import moment from "moment";

import {Banner, DropDown, Loader} from "../components/CommonComponents";
import {useDispatch, useSelector} from "react-redux";
import {getLegalList} from "../redux/action";
import {getUser} from "../utils/helper";

const Legal = props => {
    const [athleteList, setAthleteList] = useState([]);
    const [groupArray, setGroupArray] = useState(null);
    const [params, setParams] = useState({
        athlete_id: ''
    });

    const groupBy = (array, key) => {
        return array.reduce((result, currentValue) => {
            (result[currentValue[key]] = result[currentValue[key]] || []).push(
                currentValue
            );
            return result;
        }, {});
    };

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Legal.loading);
    const legalList = useSelector(state => state.Legal.legalList);

    useEffect(() => {
        dispatch(getLegalList(params))
    }, [dispatch, params]);

    useEffect(() => {
        legalList.athletes && setAthleteList(legalList.athletes.map((itm) => {
            return {
                value: itm.id,
                name: itm.first_name
            }
        }));
        legalList.files && legalList.files.map((item) => {
            return item.day_name = moment(item.updated_at).format('DD MMMM');
        });
        if (legalList.files) {
            legalList.files.length > 0 && legalList.files.sort((a,b) =>{
                return new Date(b.updated_at) - new Date(a.updated_at)
            });
            const personGroupedByColor = groupBy(legalList.files, 'day_name');
            const arr = [];
            for (let key in personGroupedByColor) {
                arr.push({day: key, files: personGroupedByColor[key]});
            }
            setGroupArray(arr);
        }
    }, [legalList]);

    const onSelect = (e) => {
        setParams({
            ...params,
            [e.target.name]: e.target.value
        });
    };

    return (
        <>
            {loading && <Loader/>}
            <div className="legal">
                {JSON.parse(getUser()).is_admin ?
                    <Banner
                        title='Legal'
                        RedirectTo={`${props.match.url}/upload`}
                        buttonText='Upload file'
                        backClick={() => console.log('')}
                    /> :
                    <Banner
                        title='Legal'
                    />
                }
                <div className="center-container">
                    { JSON.parse(getUser()).is_admin ? <div className="filterBox d-flex">
                        <DropDown
                            onselect={onSelect}
                            dropDownHeading={<svg
                                width="2em"
                                height="2em"
                                viewBox="0 0 16 16"
                                className="bi bi-person-fill mb-2"
                                fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path fillRule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                            </svg>
                            }
                            dropDownSelected='All athletes'
                            dropDownOption={athleteList}
                            name='athlete_id'
                        />
                    </div> : null}
                    {
                        !loading && groupArray &&
                        groupArray.length > 0 ?
                            groupArray.map((file, key) => <div key={key}>
                                <div className="heading d-flex">
                                    <h3>{file.day}</h3>
                                </div>
                                <div className="folderBox justify-content-center pb-0">
                                    <div className="row d-flex pl-3">
                                        {
                                            file.files.map((f, key) =>
                                                <div key={key} className="files mr-3 mb-5">
                                                    <Link to={`legal/view/${f.id}`} className="link">
                                                        {JSON.parse(getUser()).is_admin ?
                                                            <span className="label">{f.assigned_to_name}</span> : ''}
                                                        <img src="https://dev.samprofiles.com/images/file.png" alt="file"/>
                                                        <p>{f.custom_properties.original_name}</p>
                                                    </Link>
                                                </div>)
                                        }
                                    </div>
                                </div>
                        </div>) :
                            groupArray && groupArray.length === 0 &&
                            <div className='f-18 py-5 px-3'>
                                There are no legal files in here. Add files by clicking the "Upload file" button in the top right corner.
                            </div>
                    }
                </div>
            </div>
        </>
    );
};

export default Legal;

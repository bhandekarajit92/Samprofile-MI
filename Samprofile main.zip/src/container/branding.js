import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {Banner, DeleteConfirmDialog, DropDown, Loader} from '../components/CommonComponents';
import {AddBrandingFolder, ShowFile} from '../components/BrandingComponents';
import { getBrandingList, addBrandingFolder, deleteFolder } from '../redux/action';
import {apiUrl, getToken, getUser, mediaUrl, setFolderLocal} from "../utils/helper";
import validateAddBrandingFolder from '../validations/brandingValidation';

const Branding = props => {
    const [athleteList, setAthleteList] = useState([]);
    const [athlete_id, setAthleteId] = useState('');
    const [isAddOpen, setAddOpen] = useState(false);
    const[name, setName] = useState('');
    const [folder, setFolder] = useState('');
    const [isOpenPopup, setPopupOpen] = useState(false);
    const [selectedImg, setImg] = useState('');
    const [next, setNext] = useState(0);
    const [prev, setPrev] = useState(0);
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [errors, setErrors] = useState({});
    const [loadZip, setLoadZip] = useState(false);

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Branding.loading);
    const brandingList = useSelector(state => state.Branding.brandingList);

    useEffect(() => {
        if (brandingList && brandingList.all_athletes && brandingList.all_athletes.length > 0) {
            setAthleteList(brandingList.all_athletes.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [brandingList]);

    useEffect(() => {
        if(!JSON.parse(getUser()).is_admin){
            setAthleteId(JSON.parse(getUser()).id)
        }
    }, [])

    useEffect(() => {
        if(!JSON.parse(getUser()).is_admin) {
            dispatch(getBrandingList({
                folder: '',
                athlete_id: JSON.parse(getUser()).id
            }))
        } else {
            if(props && props.location && props.location.state) {
                setFolder(props.location.state.folder)
                dispatch(getBrandingList({
                    folder: props.location.state.folder
                }))
            } else {
                dispatch(getBrandingList({
                    folder: '',
                    athlete_id: ''
                }))
            }
        }
    }, [props, dispatch])

    useEffect(() => {
        dispatch(getBrandingList({
            folder,
            athlete_id
        }))
    }, [folder, dispatch, athlete_id])

    const handleAddFolder = () => {
        const { errors, isValid } = validateAddBrandingFolder({name});
        setErrors(errors);
        if(isValid) {
            dispatch(addBrandingFolder({
                folder,
                name,
                callBack: () => {
                    setAddOpen(false);
                    setName('');
                }
            }))
        }
    }

    const handleDelete = () => {
        const tmpFolder = folder.split('/');
        tmpFolder.splice(tmpFolder.length - 1);
        dispatch(deleteFolder({
            folder,
            path: tmpFolder.join('/'),
            callBack: () => {
                setFolder(tmpFolder.join('/'))
                setFolderLocal(tmpFolder.join('/'))
            },
            callBackDelete: () => setDeleteOpen(false)
        }));
    }

    const handleNextPrev = (type) => {
        if(type === 'next') {
            setPrev(selectedImg + 1)
            setImg(selectedImg + 1)
            setNext(selectedImg + 1);
        } else if(type === 'prev') {
            setImg(selectedImg - 1)
            setPrev(selectedImg - 1);
            setNext(selectedImg - 1);
        }
    }

    const handleDownloadZip = () => {
        const bodyFormData = new FormData();
        bodyFormData.append('athlete_id', athlete_id);
        bodyFormData.append('folder', folder);
        const requestOptions = {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${getToken()}`,
            },
            body: bodyFormData
        };
        setLoadZip(true);
        fetch(`https://cors-anywhere.herokuapp.com/${apiUrl}branding/downloadZip`, requestOptions).then(response =>  response.blob()).then(res => {
                const blob = new Blob([res], {type: 'application/zip'});
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', `_branding.zip`);
                document.body.appendChild(link);
                link.click();
                link.parentNode.removeChild(link);
                setLoadZip(false)
            })
    };

    return (
        <>
            {(loading || loadZip) && <Loader/>}
            <div className="branding">
                {
                    JSON.parse(getUser()).is_admin ?
                        <Banner
                            title='Branding'
                            RedirectTo={`${props.match.url}/create`}
                            buttonText='Upload'
                            isBranding={true}
                            setAddOpen={setAddOpen}
                            isDeteteFolder={brandingList && brandingList.folder && brandingList.folder[0] !== ''}
                            handleDelete={() => setDeleteOpen(true)}
                            handleDownloadZip={handleDownloadZip}
                            backClick={() => console.log('')}
                        />:
                        <Banner
                            title='Branding'
                        />
                }
                <div className="centerContainer">
                    <div className="filterBox d-flex">
                        {
                            JSON.parse(getUser()).is_admin &&
                            <div>
                                <DropDown
                                    onselect={(e) => {
                                        setAthleteId(e.target.value);
                                    }}
                                    dropDownHeading={<svg
                                        width="2em"
                                        height="2em"
                                        viewBox="0 0 16 16"
                                        className="bi bi-person-fill mb-2"
                                        fill="currentColor"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path fillRule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                    </svg>
                                    }
                                    dropDownSelected='All athletes'
                                    dropDownOption={athleteList}
                                    name='athlete_id'
                                    value={athlete_id}
                                />
                            </div>
                        }
                    </div>
                    <div className="folderBox">
                        <div className="row p-2">
                            {
                                !loading && brandingList && ((brandingList.directories && brandingList.directories.length >0) ||
                                    (brandingList.files && brandingList.files.length > 0)) ?
                                    <>
                                        {
                                            brandingList.directories && brandingList.directories.length > 0 &&
                                            brandingList.directories.map((itm,key) =>
                                                <div 
                                                    className="col-lg-2 col-md-3 col-4 cursor-pointer link"
                                                    key={key}
                                                    onClick={() => {
                                                        setFolder(itm.path);
                                                        setFolderLocal(itm.path);
                                                    }}
                                                >
                                                    <img
                                                        className='img-fluid'
                                                        src="https://dev.samprofiles.com/images/folder_icon_blue.png"
                                                        alt="folder"
                                                    />
                                                    {itm.basename}
                                                </div>
                                            )
                                        }
                                        {
                                            brandingList.files && brandingList.files.length > 0 &&
                                            brandingList.files.map((itm, key) =>
                                                <div
                                                    className="col-lg-2 col-md-3 col-4 cursor-pointer link"
                                                    onClick={() => {
                                                        setPopupOpen(true);
                                                        setImg(key);
                                                        setPrev(key);
                                                        setNext(key)
                                                    }}
                                                    key={key}
                                                >
                                                    <img
                                                        className='img-fluid'
                                                        src={folder ?
                                                            `${mediaUrl}branding/${folder}/${itm.custom_properties.original_name}` :
                                                            `${mediaUrl}branding/${itm.custom_properties.original_name}`
                                                        }
                                                        alt="file"
                                                    />
                                                    <h6 className='img-name'>{itm.custom_properties.original_name}</h6>
                                                </div>
                                            )
                                        }
                                    </> :
                                    brandingList && ((brandingList.directories && brandingList.directories.length  === 0) &&
                                    (brandingList.files && brandingList.files.length === 0)) &&
                                    <div>
                                        <p className='f-18 p-3'>There are no media files in here. Add files by clicking the "Upload" button in the top right corner.</p>
                                    </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
            <AddBrandingFolder
                isAddOpen={isAddOpen}
                setAddOpen={setAddOpen}
                name={name}
                setName={setName}
                handleAddFolder={handleAddFolder}
                errorMsg={errors && errors.name}
                errors={errors}
                setErrors={setErrors}
            />
            <ShowFile
                isOpenPopup={isOpenPopup}
                setPopupOpen={setPopupOpen}
                brandingList={brandingList}
                selectedImg={selectedImg}
                prev={prev}
                next={next}
                handleNextPrev={handleNextPrev}
                folder={folder}
                setImg={setImg}
            />
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

Branding.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default Branding;

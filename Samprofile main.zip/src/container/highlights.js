import React, {useEffect, useState} from 'react';
import {Link} from 'react-router-dom';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from "prop-types";

import {Banner, DropDown, Loader} from '../components/CommonComponents';
import {getHighlightsList, resetHIGHLIGHTSDetail} from "../redux/action";
import {getUser, orderList} from "../utils/helper";

const Highlights = props => {

    const [athleteList, setAthleteList] = useState([]);
    const [params, setParams] = useState({
        show_docs_for: '',
        order_by: ''
    });

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Highlights.loading);
    const highlightList = useSelector(state => state.Highlights.highlightList);

    useEffect(() => {
        if (highlightList && highlightList.athletes && highlightList.athletes.length > 0) {
            setAthleteList(highlightList.athletes.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [highlightList]);

    const onSelect = (e) => {
        setParams({
            ...params,
            [e.target.name]: e.target.value
        });
        dispatch(getHighlightsList({
            ...params,
            [e.target.name]: e.target.value
        }))
    };

    useEffect(() => {
        if(!JSON.parse(getUser()).is_admin) {
            setParams(prevState => ({
                ...prevState,
                show_docs_for: JSON.parse(getUser()).id
            }));
            dispatch(getHighlightsList({
                show_docs_for: JSON.parse(getUser()).id
            }))
        } else {
            dispatch(getHighlightsList({
                show_docs_for: '',
                order_by: ''
            }))
        }
    }, [dispatch]);

    function createMarkup(html) {
        return {__html: html};
    }

    return (
        <>
            {loading && <Loader/>}
            <div className="highlights">
                {
                    JSON.parse(getUser()).is_admin ?
                        <Banner
                            title='Highlights'
                            RedirectTo={`${props.match.url}/create`}
                            buttonText='Create new'
                            backClick={() => dispatch(resetHIGHLIGHTSDetail())}
                        /> :
                        <Banner
                            title='Highlights'
                        />
                }
                <div className="container-fluid">
                    <div className="row justify-content-between pb-2">
                        <div className="col-md-6 col-12">
                            {
                                JSON.parse(getUser()).is_admin &&
                                <DropDown
                                    onselect={onSelect}
                                    dropDownHeading={<svg
                                        width="2em"
                                        height="2em"
                                        viewBox="0 0 16 16"
                                        className="bi bi-person-fill mb-2"
                                        fill="currentColor"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path fillRule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                                    </svg>
                                    }
                                    dropDownSelected='All athletes'
                                    dropDownOption={athleteList}
                                    name='show_docs_for'
                                />
                            }
                        </div>
                        <div className="col-md-6 col-12 text-md-right">
                            <DropDown
                                onselect={onSelect}
                                dropDownHeading={<svg
                                    width="2em"
                                    height="2em"
                                    viewBox="0 0 16 16"
                                    className="bi bi-sort-up-alt mb-2"
                                    fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path fillRule="evenodd" d="M3 14a.5.5 0 0 0 .5-.5v-10a.5.5 0 0 0-1 0v10a.5.5 0 0 0 .5.5z"/>
                                    <path fillRule="evenodd" d="M5.354 5.854a.5.5 0 0 0 0-.708l-2-2a.5.5 0 0 0-.708 0l-2 2a.5.5 0 1 0 .708.708L3 4.207l1.646 1.647a.5.5 0 0 0 .708 0zM7 6.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 0-1h-3a.5.5 0 0 0-.5.5zm0 3a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 0-1h-5a.5.5 0 0 0-.5.5zm0 3a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 0-1h-7a.5.5 0 0 0-.5.5zm0-9a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0-.5.5z"/>
                                </svg>
                                }
                                dropDownSelected='Sort by'
                                dropDownOption={orderList}
                                name='order_by'
                            />
                        </div>
                    </div>
                    <div className="row justify-content-lg-start justify-content-center">
                        {
                            !loading && highlightList.documents &&
                            highlightList.documents.length > 0 ?
                                highlightList.documents.map((itm, key) =>
                                    <Link
                                        key={key}
                                        to={JSON.parse(getUser()).is_admin ? `/highlights/${itm.id}/edit` : `/highlights/${itm.id}/view`}
                                        className="mainFrame col-12 col-lg-7 d-flex mx-lg-4 mx-0 p-3 pt-5 mt-lg-3 mb-lg-3 mt-3 bg-white">

                                        <div className="media-label position-absolute line-height-22 f-14 text-white">
                                            <span>{itm.created_for_name}</span>
                                        </div>

                                        <div className="embed-responsive"
                                             dangerouslySetInnerHTML={createMarkup(itm.contents)}/>


                                        <div className="media-bottom-text position-absolute f-14">
                                            <span>{itm.title}</span>
                                        </div>
                                    </Link>)
                                :
                                highlightList.documents &&
                                highlightList.documents.length === 0 &&
                                <div className='f-18 py-5 px-3'>
                                    {
                                        JSON.parse(getUser()).is_admin ?
                                            'There are no highlights in here. Create one by clicking the "Create new" button in the top right corner.' :
                                            'There are no highlights in here.'
                                    }
                                </div>
                        }
                    </div>
                </div>
            </div>
        </>
    );
};

Highlights.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default Highlights;

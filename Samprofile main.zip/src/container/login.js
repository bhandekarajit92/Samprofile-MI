import React, {useEffect, useState} from 'react';
import {Link, useHistory} from 'react-router-dom';
import validator from 'validator';
import {useDispatch, useSelector} from 'react-redux';

import { Input, Loader } from "../components/CommonComponents";
import validateLogin from '../validations/login';
import Logo from '../assets/images/login_logo.png';
import {loginUser} from "../redux/action";
import {getToken, getUser} from "../utils/helper";

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        email: false,
        password: false
    });

    const dispatch = useDispatch();
    const history = useHistory();

    const loading = useSelector(state => state.Login.loading);

    useEffect(() => {
        if(getToken()) {
            if(getUser() && JSON.parse(getUser()).is_admin) {
                history.push('/athletes');
            } else if(getUser() && JSON.parse(getUser()).is_admin) {
                history.push('/dashboard');
            }
        }
    }, [history])

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateLogin({ email, password });
        setErrors(errors);
        setPassword('');
        if(isValid){
            dispatch(loginUser({
                email,
                password,
                callBack: () => history.push('/')
            }));
        }
    };

    return (
        <>
            {loading && <Loader/>}
            <div className="flex-container row">
                <div className="flex-imgBox col-12 col-md-12 col-lg-6 col-xl-8">
                    <h1>Manage<br/>your<br/>arsenal</h1>
                </div>
                <div className="flex-loginBox col-12 col-md-12 col-lg-6 col-xl-4">
                    <div className="inner">
                        <div className="logo">
                            <img src={Logo} className='img-fluid' alt="logo"/>
                        </div>
                        <h2 className='mb-0 text-center'>Login to your SAM account</h2>
                        <form onSubmit={handleSubmit}>
                            <div>
                                <Input
                                    type='email'
                                    placeholder='Email'
                                    name='email'
                                    className={errors.email ?
                                        'form-control is-invalid' : 'form-control'}
                                    value={email}
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                        setValid({ ...valid, email: validator.isEmail(e.target.value)})
                                        setErrors({ ...errors, email: false })
                                    }}
                                    errorMsg={errors && errors.email}
                                />
                            </div>
                            <div className='input'>
                                <Input
                                    type='password'
                                    placeholder='Password'
                                    name='password'
                                    className={errors.password ?
                                        'form-control is-invalid' : 'form-control'}
                                    value={password}
                                    onChange={(e) => {
                                        setPassword(e.target.value);
                                        setValid({ ...valid, password: e.target.value.trim().length >= 6})
                                        setErrors({ ...errors, password: false })
                                    }}
                                    errorMsg={errors && errors.password}
                                />
                            </div>
                            <div>
                                <Link to='/forgot-password' className='forgot f-14'>Forgot Password?</Link>
                            </div>
                            <div className="button">
                                <button
                                    type="submit"
                                    onClick={handleSubmit}
                                    className="btn border-0 rounded-0"
                                >
                                    Log In
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Login;
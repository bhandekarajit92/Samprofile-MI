import React, {useEffect, useState} from 'react';
import { useHistory } from 'react-router-dom';
import validator from "validator";
import {useDispatch, useSelector} from "react-redux";

import { Input, Loader } from "../components/CommonComponents";
import validateResetPassword from "../validations/resetPassword";
import Logo from "../assets/images/login_logo.png";
import {resetPassword} from "../redux/action";

const ResetPassword = (props) => {
    const [form, setForm] = useState({
        password: '',
        confirmPassword: ''
    });
    const [token, setToken] = useState('');
    const [email, setEmail] = useState('');
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        password: false,
        confirmPassword: false
    });
    const [accept, setAccept] = useState(false);

    const dispatch = useDispatch();
    const history = useHistory();

    const loading = useSelector(state => state.Login.loading);

    useEffect(() => {
        if(props && props.location && props.location.search) {
            const tempToken = props.location.search.split('&')[0];
            const tempEmail = props.location.search.split('&')[1];
            setToken(tempToken.split('=')[1]);
            setEmail(tempEmail.split('=')[1])
        }
    }, [props])

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateResetPassword({
            password: form.password,
            confirmPassword: form.confirmPassword
        });
        setErrors(errors);
        if(isValid){
            dispatch(resetPassword({
                code: token,
                password: form.password,
                redirectUrl: () => history.push('/login')
            }))
        }
    }

    return (
        <>
            {loading && <Loader/>}
            <div className="flex-container row reset-password">
                <div className="flex-imgBox col-12 col-md-12 col-lg-6 col-xl-8">
                    <h1>Manage<br/>your<br/>arsenal</h1>
                </div>
                <div className="flex-loginBox col-12 col-md-12 col-lg-6 col-xl-4">
                    <div className="inner">
                        <div className="logo">
                            <img src={Logo} className='img-fluid' alt="logo"/>
                        </div>
                        <h2 className='mb-0 text-center pb-1 pt-4'>Reset your password</h2>
                        <form onSubmit={handleSubmit} className='pt-0'>
                            <div  className='input'>
                                <Input
                                    type='email'
                                    placeholder='email'
                                    name='email'
                                    className='form-control'
                                    value={email}
                                    disabled={true}
                                />
                            </div>
                            <div  className='input'>
                                <Input
                                    type='password'
                                    placeholder='New password'
                                    name='password'
                                    className={errors.password ?
                                        'form-control is-invalid' : 'form-control'
                                    }
                                    value={form.password}
                                    onChange={(e) => {
                                        setForm({...form, password: e.target.value});
                                        setValid({ ...valid, password: true})
                                        setErrors({ ...errors, password: false })
                                    }}
                                    errorMsg={errors && errors.password}
                                />
                            </div>
                            <div  className='input'>
                                <Input
                                    type='password'
                                    placeholder='Confirm new password'
                                    name='confirmPassword'
                                    className={errors.confirmPassword ?
                                        'form-control is-invalid' : 'form-control'
                                    }
                                    value={form.confirmPassword}
                                    onChange={(e) => {
                                        setForm({...form, confirmPassword: e.target.value});
                                        setValid({ ...valid, password: validator.equals(form.password, e.target.value)})
                                        setErrors({ ...errors, confirmPassword: false })
                                    }}
                                    errorMsg={errors && errors.confirmPassword}
                                />
                            </div>
                            <div className="form-check mt-3">
                                <input
                                    className="form-check-input"
                                    type="checkbox"
                                    value={accept}
                                    id="defaultCheck1"
                                    checked={accept}
                                    onChange={e => setAccept(e.target.checked)}
                                />
                                <label className="form-check-label f-12" htmlFor="defaultCheck1">
                                    <strong>I agree</strong>&nbsp;
                                    to the <u>
                                        <a href='https://dev.samprofiles.com/media/SAM_TERMS_AND_CONDITIONS.pdf' target='_blank' rel="noopener noreferrer">
                                            Terms & Conditions
                                        </a>
                                    </u>
                                </label>
                            </div>
                            <div className="button">
                                <button
                                    type="submit"
                                    onClick={handleSubmit}
                                    className="btn border-0 rounded-0"
                                    disabled={!accept}
                                >
                                    Reset password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default ResetPassword;
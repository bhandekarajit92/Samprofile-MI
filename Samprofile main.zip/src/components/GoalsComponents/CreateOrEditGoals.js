import React, {useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import {useDispatch, useSelector} from 'react-redux';
import moment from "moment";

import {Input, RichTextEditor, Loader} from '../CommonComponents';
import {createOrEditGoals, getAthletesList, getGoalDetail, resetGoalDetail} from '../../redux/action';
import validateCreateOrEditGoal from "../../validations/createOrEditGoalValidation";
import {getUser} from "../../utils/helper";


const CreateOrEditGoals = ({isCreateOrEditGoalOpen, setCreateOrEditGoalOpen, goalId, setGoalId, idForDashboard}) => {
    const [form, setForm] = useState({
        title: '',
        start_date: '',
        due_date: '',
        benchmark: '',
        situational_analysis: '',
        golden_circle: '',
    });
    const [athlete, setAthlete] = useState('');
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        title: false,
        start_date: false,
        due_date: false,
        benchmark: false,
        situational_analysis: false,
        golden_circle: false
    });
    const [selectedTab, setSelectedTab] = useState('');
    const [type, setType] = useState('text');

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Goals.loading);
    const goalDetail = useSelector(state => state.Goals.goalDetail);
    const loadingAthlete = useSelector(state => state.Athlete.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);

    useEffect(() => {
        if(idForDashboard) {
            setAthlete(idForDashboard)
        }
    }, [idForDashboard])

    useEffect(() => {
        if(JSON.parse(getUser()).is_admin){
            dispatch(getAthletesList());
        }
    }, [dispatch]);

    useEffect(() => {
        if (goalId) {
            dispatch(getGoalDetail(goalId))
        }
    }, [dispatch, goalId]);

    useEffect(() => {
        if (goalDetail) {
            const {title, start_date, due_date, benchmark, situational_analysis, golden_circle, user_id} = goalDetail;
            setForm({
                title: title || '',
                start_date: start_date ? moment(start_date).format('YYYY-MM-DD') : '',
                due_date: due_date ? moment(due_date).format('YYYY-MM-DD') : '',
                benchmark: benchmark || '',
                situational_analysis: situational_analysis || '',
                golden_circle: golden_circle || ''
            })
            setAthlete(user_id)
        }
    }, [goalDetail])

    useEffect(() => {
        if (athletesList && athletesList.length > 0) {
            setAthlete(athletesList[0].id)
        }
    }, [athletesList])

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const handleCallOnlyAdmin = () => {
        if(JSON.parse(getUser()).is_admin) {
            setAthlete(athletesList[0].id);
            dispatch(getAthletesList());
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const {errors, isValid} = validateCreateOrEditGoal(form);
        setErrors(errors);
        if (isValid) {
            dispatch(createOrEditGoals({
                form,
                athleteId: JSON.parse(getUser()).is_admin ? athlete : JSON.parse(getUser()).id,
                callBack: () => {
                    setCreateOrEditGoalOpen(false);
                    setGoalId(null);
                    handleClose();
                    handleCallOnlyAdmin();
                },
                id: goalId
            }))
        }
    };

    const handleReachTextChangeBenchmark = (data) => {
        setForm({
            ...form,
            benchmark: data
        })
    };

    const handleReachTextChangeAnalysis = (data) => {
        setForm({
            ...form,
            situational_analysis: data
        })
    };

    const handleReachTextChangeGoldenCircle = (data) => {
        setForm({
            ...form,
            golden_circle: data
        })
    };

    const handleModalView = () => {
        document.getElementById('leftModalForm').className = "col-lg-5 border-right borderRightUnset";
        document.getElementById('rightModalForm').className = "col-lg-7 col-12";
        document.getElementById('modal-content').className = "modal-content transitionWidth w-100";
        document.getElementById('modalBtn').className = "col-lg-5 mb-3";
    };

    const handleClose = () => {
        document.getElementById('leftModalForm').className = "col-12";
        document.getElementById('rightModalForm').className = "d-none";
        document.getElementById('modal-content').className = "modal-content modalWidth";
        document.getElementById('modalBtn').className = "col-12 mb-3";
        setSelectedTab('')
    }

    return (
        <>
            {(loading || loadingAthlete) && <Loader/>}
            <div className="create-edit-goals">
                <div
                    className={isCreateOrEditGoalOpen ? 'modal fade show bd-example-modal-xl d-block' : 'd-none'}
                    style={{overflowY: "auto"}}
                >
                    <div className="modal-dialog modal-xl modal-dialog-centered">
                        <div id="modal-content" className="modal-content modalWidth">
                            <div className="row">
                                <div id="leftModalForm" className="col-12">
                                    <div className="modal-header border-0">
                                        {
                                            idForDashboard ?
                                                <h5 className="modal-title" id="exampleModalLongTitle">
                                                    {goalId ? 'Edit goal' : 'Add new goal'} {'\u00A0'}
                                                </h5>
                                                :
                                                JSON.parse(getUser()).is_admin ?
                                                    <h5 className="modal-title" id="exampleModalLongTitle">
                                                        {goalId ? 'Edit goal for' : 'Add new goal for'} {'\u00A0'}
                                                        <div className="btn-group">
                                                    {
                                                        !goalId ? <select
                                                                className="gray-bg-color custom-select my-1 mr-sm-2"
                                                                id="inlineFormCustomSelectPref"
                                                                value={athlete}
                                                                name='athlete'
                                                                onChange={(e) => setAthlete(e.target.value)}
                                                            >
                                                                {
                                                                    athletesList && athletesList.map(data =>
                                                                        <option value={data.id} key={data.id}>
                                                                            {data.first_name}
                                                                        </option>)
                                                                }
                                                            </select> :
                                                            <p className="mb-0 light-dark font-weight-bold">
                                                                {
                                                                    athletesList &&
                                                                    athletesList.find(itm => itm.id === athlete) &&
                                                                    athletesList.find(itm => itm.id === athlete).first_name
                                                                }
                                                            </p>
                                                    }
                                                </div>
                                                    </h5>
                                                    :
                                                    <h5 className="modal-title" id="exampleModalLongTitle">
                                                        {goalId ? 'Edit goal' : 'Add new goal'} {'\u00A0'}
                                                    </h5>
                                        }
                                        <button type="button" className="close"
                                                onClick={() => {
                                                    setCreateOrEditGoalOpen(false);
                                                    setGoalId(null);
                                                    handleClose();
                                                    dispatch(resetGoalDetail());
                                                }}>
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div className="modal-body">
                                        <Input
                                            id='title'
                                            type='text'
                                            placeholder="Goal Name"
                                            className={errors.title ?
                                                'form-control is-invalid' : 'customInput w-100 mt-3'
                                            }
                                            name='title'
                                            value={form.title}
                                            onChange={(e) => {
                                                handleChange(e);
                                                setValid({...valid, title: e.target.value.trim().length >= 3});
                                                setErrors({...errors, title: false});
                                            }}
                                            maxLength={30}
                                            errorMsg={errors && errors.title}
                                        />
                                        <div className="row">
                                            <div className="col-12 col-lg-6 col-md-6">
                                                <span>
                                                    <input
                                                        name='start_date'
                                                        type={type}
                                                        className="customInput mt-5 w-100"
                                                        placeholder="Start Date"
                                                        value={form.start_date}
                                                        onChange={(e) => {
                                                            handleChange(e);
                                                            setValid({...valid, start_date: e.target.value.trim().length >= 3});
                                                            setErrors({...errors, start_date: false});
                                                        }}
                                                        onFocus={() => setType(type === 'text' ? 'date' : 'text')}
                                                        onBlur={() => setType(type === 'text' ? 'date' : 'text')}
                                                        onKeyDown={e => e.preventDefault()}
                                                        min={moment().format('YYYY-MM-DD')}
                                                    />
                                                    <div className="invalid-feedback d-block">
                                                        {errors && errors.start_date}
                                                    </div>
                                                </span>
                                            </div>
                                            <div className="col-12 col-lg-6 col-md-6">
                                                <span>
                                                    <input
                                                        name='due_date'
                                                        type={type}
                                                        className="customInput mt-5 w-100"
                                                        placeholder="Due Date"
                                                        value={form.due_date}
                                                        onFocus={() => setType(type === 'text' ? 'date' : 'text')}
                                                        onBlur={() => setType(type === 'text' ? 'date' : 'text')}
                                                        onChange={(e) => {
                                                            handleChange(e);
                                                            setValid({...valid, due_date: e.target.value.trim().length >= 3});
                                                            setErrors({...errors, due_date: false});
                                                        }}
                                                        onKeyDown={e => e.preventDefault()}
                                                        min={moment().format('YYYY-MM-DD')}
                                                    />
                                                    <div className="invalid-feedback d-block">
                                                        {errors && errors.due_date}
                                                    </div>
                                                </span>
                                            </div>
                                        </div>
                                        <div className="row mt-5">
                                            <div className="col-12">
                                                <div
                                                    className="nav flex-column nav-pills"
                                                >
                                                    <button
                                                        className={selectedTab === "v-pills-Add-golden-circle" ?
                                                            "btn customTab text-center mb-4 f-18 nav-link active" :
                                                            "btn customTab text-center mb-4 f-18 nav-link"
                                                        }
                                                        name="navLink"
                                                        onClick={() => {
                                                            handleModalView();
                                                            setSelectedTab('v-pills-Add-golden-circle')
                                                        }}
                                                    >
                                                        {goalId ?
                                                            <>
                                                                <svg
                                                                    width="1em"
                                                                    height="1em"
                                                                    viewBox="0 0 16 16"
                                                                    className="bi bi-pencil position-relative"
                                                                    fill="currentColor"
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                >
                                                                    <path fillRule="evenodd" d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5L13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175l-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                                                </svg>
                                                                {`\u00A0`}{`\u00A0`}
                                                                <span className="font-family">Edit</span>
                                                            </> :
                                                            <>
                                                                <svg
                                                                    width="2em"
                                                                    height="2em"
                                                                    viewBox="0 0 16 16"
                                                                    className="bi bi-plus position-relative"
                                                                    fill="currentColor"
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                >
                                                                    <path fillRule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                                                                </svg>{`\u00A0`}
                                                                <span className="font-family">Add</span>
                                                            </>
                                                        } match report
                                                    </button>

                                                    <button
                                                        className={selectedTab === "v-pills-Add-situation-analysis" ?
                                                            "btn customTab text-center mb-4 f-18 nav-link active" :
                                                            "btn customTab text-center mb-4 f-18 nav-link"
                                                        }
                                                        name="navLink"
                                                        onClick={() => {
                                                            handleModalView();
                                                            setSelectedTab('v-pills-Add-situation-analysis')
                                                        }}
                                                    >
                                                        {goalId ?
                                                            <>
                                                                <svg
                                                                    width="1em"
                                                                    height="1em"
                                                                    viewBox="0 0 16 16"
                                                                    className="bi bi-pencil position-relative"
                                                                    fill="currentColor"
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                >
                                                                    <path fillRule="evenodd" d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5L13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175l-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                                                </svg>
                                                                {`\u00A0`}{`\u00A0`}
                                                                <span className="font-family">Edit</span>
                                                            </> :
                                                            <>
                                                                <svg
                                                                    width="2em"
                                                                    height="2em"
                                                                    viewBox="0 0 16 16"
                                                                    className="bi bi-plus position-relative"
                                                                    fill="currentColor"
                                                                    xmlns="http://www.w3.org/2000/svg"
                                                                >
                                                                    <path fillRule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                                                                </svg>{`\u00A0`}
                                                                <span className="font-family">Add</span>
                                                            </>
                                                        } situation analysis
                                                    </button>
                                                    <button
                                                    className={selectedTab === "v-pills-Add-benchmark" ?
                                                        "btn customTab text-center mb-4 f-18 nav-link active" :
                                                        "btn customTab text-center mb-4 f-18 nav-link"
                                                    }
                                                    name="navLink"
                                                    onClick={() => {
                                                        handleModalView();
                                                        setSelectedTab('v-pills-Add-benchmark')
                                                    }}
                                                >
                                                    {goalId ?
                                                        <>
                                                            <svg
                                                                width="1em"
                                                                height="1em"
                                                                viewBox="0 0 16 16"
                                                                className="bi bi-pencil position-relative"
                                                                fill="currentColor"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path fillRule="evenodd" d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5L13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175l-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                                            </svg>
                                                            {`\u00A0`}{`\u00A0`}
                                                            <span className="font-family">Edit</span>
                                                        </> :
                                                        <>
                                                            <svg
                                                                width="2em"
                                                                height="2em"
                                                                viewBox="0 0 16 16"
                                                                className="bi bi-plus position-relative"
                                                                fill="currentColor"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path fillRule="evenodd" d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                                                            </svg>{`\u00A0`}
                                                            <span className="font-family">Add</span>
                                                        </>
                                                    } benchmark
                                                </button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="rightModalForm" className="d-none">
                                    <div className="tab-content" id="v-pills-tabContent">
                                        <div
                                            className={selectedTab === "v-pills-Add-benchmark" ? "tab-pane fade show active" : "tab-pane fade"}
                                        >
                                            <div className="modal-header border-0">
                                                <h3 className="modal-title f-22 lightDark line-height-24 font-weight-normal"
                                                    id="exampleModalLongTitle">Benchmark</h3>
                                            </div>
                                            <div className="modal-body">
                                                <RichTextEditor
                                                    handleChange={handleReachTextChangeBenchmark}
                                                    value={form.benchmark}
                                                />
                                            </div>
                                        </div>
                                        <div
                                            className={selectedTab === "v-pills-Add-situation-analysis" ? "tab-pane fade show active" : "tab-pane fade"}
                                        >
                                            <div className="modal-header border-0">
                                                <h3 className="modal-title f-22 lightDark line-height-24 font-weight-normal"
                                                    id="exampleModalLongTitle">Situational analysis</h3>
                                            </div>
                                            <div className="modal-body">
                                                <RichTextEditor
                                                    handleChange={handleReachTextChangeAnalysis}
                                                    value={form.situational_analysis}
                                                />
                                            </div>
                                        </div>
                                        <div
                                            className={selectedTab === "v-pills-Add-golden-circle" ? "tab-pane fade show active" : "tab-pane fade"}
                                        >
                                            <div className="modal-header border-0">
                                                <h3 className="modal-title f-22 lightDark line-height-24 font-weight-normal"
                                                    id="exampleModalLongTitle">Match Report</h3>
                                            </div>
                                            <div className="modal-body">
                                                <RichTextEditor
                                                    handleChange={handleReachTextChangeGoldenCircle}
                                                    value={form.golden_circle}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="modalBtn" className='col-12 mb-3'>
                                    <div className="modal-footer justify-content-center border-0">
                                        <button
                                            type="submit"
                                            className="btn primary-bg-color text-white"
                                            onClick={handleSubmit}
                                        >
                                            {goalId ? 'Update' : 'Create New'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

CreateOrEditGoals.propTypes = {
    isCreateOrEditGoalOpen: PropTypes.bool,
    setCreateOrEditGoalOpen: PropTypes.func,
    goalId: PropTypes.string,
    setGoalId: PropTypes.func,
    idForDashboard: PropTypes.number
};

export default CreateOrEditGoals;

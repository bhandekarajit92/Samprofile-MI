import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";

import {Banner, Table, DeleteConfirmDialog, Loader} from "../CommonComponents";
import {CreateOrEditGoals} from "./index";
import {completedIncompletedGoal, deleteGoal, viewGoalsList} from "../../redux/action";

const ViewCompletedGoals = () => {
    const [isCreateOrEditGoalOpen, setCreateOrEditGoalOpen] = useState(false);
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [goalId, setGoalId] =  useState(null);
    const [goalEditId, setEditGoalId] =  useState(null);
    const [completedGoalList, setCompletedGoalList] = useState([]);

    const dispatch = useDispatch();

    const loading =useSelector(state => state.Goals.loading);
    const goalsData = useSelector(state => state.Goals.goalsList);

    useEffect(() => {
        dispatch(viewGoalsList());
    }, [dispatch]);

    useEffect(() => {
        if(goalsData && goalsData.length > 0) {
            setCompletedGoalList(goalsData.filter(itm => itm.completed));
        } else {
            setCompletedGoalList([]);
        }
    }, [goalsData]);

    const handleCheckEvent = (data) => {
        dispatch(completedIncompletedGoal({
            goal_id : data.id,
            completed : data.completed ? 0 : 1,
        }));
    };

    const handleDelete = () => {
        dispatch(deleteGoal({
            id: goalId,
            callBack: () => setDeleteOpen(false)
        }));
    };

    return (
        <>
            {loading && <Loader/>}
            <Banner
                title='Your Completed Goals'
                buttonText='Create new'
                count={goalsData && goalsData.filter(itm => !itm.completed).length}
                goalRedirect='/goals'
                goalBannerText={goalsData && goalsData.filter(itm => !itm.completed).length > 0 && 'View goals'}
                isGoal={true}
                setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                isCompletedGoal={true}
                classNames="min-width"
            />
            <CreateOrEditGoals
                isCreateOrEditGoalOpen={isCreateOrEditGoalOpen}
                setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                goalId={goalEditId}
                setGoalId={setEditGoalId}
            />
            <div className="container-fluid goals">
                <Table
                    setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                    setDeleteOpen={setDeleteOpen}
                    tableData={completedGoalList}
                    setGoalId={setGoalId}
                    setEditGoalId={setEditGoalId}
                    handleCheckEvent={handleCheckEvent}
                />
            </div>
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

export default ViewCompletedGoals;
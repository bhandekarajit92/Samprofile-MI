import React, { useState } from "react";
import PropTypes from "prop-types";

import { Input } from "../CommonComponents";
import createNewEventValidation from "../../validations/createNewEventValidation";

const CreateNewEvent = ({ isCreateNewEvent, setIsCreateNewEvent }) => {
  const [errors, setErrors] = useState({});
  const [availablity, setAvailablity] = useState([1]);
  const [form, setForm] = useState({
    title: "",
    location: "",
    duration: "",
    availableTime1: "",
    availableTime2: "",
    availableTime3: "",
    availableTime4: "",
    availableDate1: "",
    availableDate2: "",
    availableDate3: "",
    availableDate4: "",
    inviteEmail: "",
    note: "",
  });
  const [valid, setValid] = useState({
    title: false,
    location: false,
    duration: false,
    availableTime1: false,
    availableDate1: false
  });
  const [time] = useState([
    "00:00",
    "00:30",
    "01:00",
    "01:30",
    "02:00",
    "02:30",
    "03:00",
    "03:30",
    "04:00",
    "04:30",
    "05:00",
    "05:30",
    "06:00",
    "06:30",
    "07:00",
    "07:30",
    "08:00",
    "08:30",
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "12:00",
    "12:30",
    "13:00",
    "13:30",
    "14:00",
    "14:30",
    "15:00",
    "15:30",
    "16:00",
    "16:30",
    "17:00",
    "17:30",
    "18:00",
    "18:30",
    "19:00",
    "19:30",
    "20:00",
    "20:30",
    "21:00",
    "21:30",
    "22:00",
    "22:30",
    "23:00",
    "23:30",
    "24:00",
  ]);

  const handleAvailablity = () => {
    setAvailablity([...availablity, 1]);
  };

  const handleChange = (props) => (event) => {
    setForm({ ...form, [props]: event.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const { errors } = createNewEventValidation(form);
    setErrors(errors);
  };

  return (
    <>
      <div className="create-new-event">
        <div
          className={
            isCreateNewEvent
              ? "modal fade show bd-example-modal-xl d-block"
              : "d-none"
          }
          style={{ overflowY: "auto" }}
        >
          <div className="modal-dialog modal-lg modal-dialog-centered">
            <div id="modal-content" className="modal-content modalWidth">
              <div className="row">
                <div className="col-12">
                  <button
                    type="button"
                    className="close mr-3 mt-2"
                    onClick={() => {
                      setIsCreateNewEvent(false);
                      setErrors({});
                      setAvailablity([1]);
                    }}
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div id="leftModalForm" className="col-12 col-md-7">
                  <div className="modal-header border-0">
                    <h5 className="modal-title" id="exampleModalLongTitle">
                      Create new event
                    </h5>
                  </div>
                  <div className="row">
                    <div className="col-12">
                      <div className="modal-body">
                        <div className="form-group">
                          <Input
                              className={errors.title ?
                                  'form-control is-invalid' : 'form-control'}
                              name='address'
                              value={form.title}
                              placeholder="Event title"
                              onChange={(e) => {
                                handleChange(e);
                                setValid({ ...valid, title: e.target.value.trim().length >= 3});
                                setErrors({ ...errors, title: false });
                              }}
                              type='text'
                              errorMsg={errors && errors.title}
                              maxLength={20}
                          />
                        </div>
                        <div className="form-group">
                          <Input
                              className={errors.location ?
                                  'form-control is-invalid' : 'form-control'}
                              name='location'
                              value={form.location}
                              placeholder="Location"
                              onChange={(e) => {
                                handleChange(e);
                                setValid({ ...valid, location: e.target.value.trim().length >= 3});
                                setErrors({ ...errors, location: false });
                              }}
                              type='text'
                              errorMsg={errors && errors.location}
                              maxLength={20}
                          />
                        </div>
                        <div className="form-group">
                          <label className='f-14'/>
                          <select
                              className="form-control select"
                              id="duration"
                              name="duration"
                              onChange={(e) => {
                                handleChange(e);
                                setValid({...valid, duration: true});
                                setErrors({...errors, duration: false});
                              }}
                              value={form.duration}
                          >
                            <option selected>Duration</option>
                            <option value="0.5">0.5</option>
                            <option value="1">1</option>
                            <option value="1.5">1.5</option>
                            <option value="2">2</option>
                            <option value="2.5">2.5</option>
                            <option value="3">3</option>
                            <option value="3.5">3.5</option>
                            <option value="4">4</option>
                          </select>
                          <div className="invalid-feedback d-block">
                            {errors && errors.duration}
                          </div>
                        </div>
                        {availablity.length >= 1 && (
                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <Input
                                    name='availableDate1'
                                    type="date"
                                    placeholder="Date"
                                    value={form.availableDate1}
                                    className={
                                      errors.availableDate1
                                          ? "form-control is-invalid"
                                          : "form-control"
                                    }
                                    errorMsg={errors && errors.availableDate1}
                                    onChange={(e) => {
                                      handleChange(e);
                                      setValid({ ...valid, availableDate1: true});
                                      setErrors({ ...errors, availableDate1: false });
                                    }}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <label className='f-14'/>
                                <select
                                    className='form-control select'
                                    value={form.availableTime1}
                                >
                                  <option selected>Time</option>
                                  {time.map((item) => (
                                      <option value={item} key={item.toString()}>
                                        {item}
                                      </option>
                                  ))}
                                </select>
                                <div className="invalid-feedback d-block">
                                  {errors && errors.availableTime1}
                                </div>
                              </div>
                            </div>
                        )}
                        {availablity.length >= 2 && (
                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <Input
                                    name='availableDate2'
                                    type="date"
                                    placeholder="Date"
                                    value={form.availableDate2}
                                    className="form-control"
                                    onChange={(e) => handleChange(e)}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <label className='f-14'/>
                                <select
                                    className='form-control select'
                                    value={form.availableTime2}
                                >
                                  <option selected>Time</option>
                                  {time.map((item) => (
                                      <option value={item} key={item.toString()}>
                                        {item}
                                      </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                        )}
                        {availablity.length >= 3 && (
                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <Input
                                    name='availableDate3'
                                    type="date"
                                    placeholder="Date"
                                    value={form.availableDate3}
                                    className="form-control"
                                    onChange={(e) => handleChange(e)}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <label className='f-14'/>
                                <select
                                    className='form-control select'
                                    value={form.availableTime3}
                                >
                                  <option selected>Time</option>
                                  {time.map((item) => (
                                      <option value={item} key={item.toString()}>
                                        {item}
                                      </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                        )}
                        {availablity.length >= 4 && (
                            <div className="form-row">
                              <div className="form-group col-md-6">
                                <Input
                                    name='availableDate4'
                                    type="date"
                                    placeholder="Date"
                                    value={form.availableDate4}
                                    className="form-control"
                                    onChange={(e) => handleChange(e)}
                                />
                              </div>
                              <div className="form-group col-md-6">
                                <label className='f-14'/>
                                <select
                                    className='form-control select'
                                    value={form.availableTime4}
                                >
                                  <option selected>Time</option>
                                  {time.map((item) => (
                                      <option value={item} key={item.toString()}>
                                        {item}
                                      </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                        )}
                        <div className="row">
                          <div className="col my-3 ">
                            {availablity.length < 4 ? (
                              // eslint-disable-next-line
                              <a
                                href="#"
                                style={{
                                  textDecoration: "none",
                                  color: "black",
                                }}
                                onClick={handleAvailablity}
                              >
                                + Add availablity
                              </a>
                            ) : null}
                            <div
                              className="alert alert-secondary p-1 mt-3"
                              role="alert"
                            >
                              <div className="row">
                                <div className="col-2">
                                  <svg
                                      width="1.5em"
                                      height="1.5em"
                                      viewBox="0 0 16 16"
                                      className="bi bi-info-circle m-2"
                                      fill="currentColor"
                                      xmlns="http://www.w3.org/2000/svg"
                                  >
                                    <path fillRule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                    <path d="M8.93 6.588l-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588z"/>
                                    <circle cx="8" cy="4.5" r="1"/>
                                  </svg>
                                </div>
                                <div className="col-10">
                                  <p className="mb-1">
                                    <small>
                                      Add available times to give your recipient
                                      options to choose from. Limit: 4
                                    </small>
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="rightModalForm" className="col-12 col-lg-5 col-md-12">
                  <div className="modal-header border-0">
                    <h5 className="modal-title" id="exampleModalLongTitle">
                      Attendees
                    </h5>
                  </div>
                  <div className="modal-body">
                    <div className="row">
                      <div className="col-12">
                        <div className="form-group">
                            <label htmlFor='inviteEmail' className='f-14'>
                              Invite with email
                            </label>
                            <textarea
                                id='inviteEmail'
                                name='inviteEmail'
                                className='form-control'
                                value={form.inviteEmail}
                            />
                            <small>Separate emails with commas</small>
                        </div>
                        <div className="form-group">
                          <label htmlFor='note' className='f-14'>
                            Note
                          </label>
                          <textarea
                              id='note'
                              name='note'
                              className='form-control'
                              value={form.note}
                              rows="4"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-center col-12 p-3">
                    <button
                      type="button"
                      className="btn btn-global"
                      onClick={handleSubmit}
                    >
                      Create event
                    </button>
                    <button
                      type="button"
                      className="btn btn-global bg-secondary ml-2"
                      onClick={() => {
                        setIsCreateNewEvent(false);
                        setErrors({});
                        setAvailablity([1]);
                      }}
                    >
                      Cancel
                    </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

CreateNewEvent.propTpyes = {
  isCreateNewEvent: PropTypes.bool,
  setIsCreateNewEvent: PropTypes.func
};

export default CreateNewEvent;

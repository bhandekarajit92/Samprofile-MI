export { default as CreateNewEvent } from "./CreateNewEvent";

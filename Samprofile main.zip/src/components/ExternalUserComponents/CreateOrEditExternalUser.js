import React, {useEffect, useState} from 'react';
import validator from 'validator';
import {useDispatch, useSelector} from 'react-redux';
import {useHistory} from 'react-router-dom';
import PropTypes from 'prop-types';

import {Banner, Input, Loader} from '../CommonComponents';
import validateCreateOrEditExternalUser from "../../validations/createOrEditExternalUserValidation";
import {getAthletesList, createOrEditExternalUser, getExternalUserDetail, resetExternalUserDetail} from "../../redux/action";
import {bytesToMegaBytes, mediaUrl} from "../../utils/helper";

const CreateOrEditExternalUser = (props) => {
    const [isDragEnterExit, setDragEnterExit] = useState(false);
    const [form, setForm] = useState({
        firstName: '',
        lastName: '',
        address: '',
        postal: '',
        city: '',
        email: '',
        profession: '',
        club: '',
        website: '',
        userImg: '',
        athletes: [],
        permission: {}
    });
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        firstName: false,
        lastName: false,
        address: false,
        postal: false,
        city: false,
        email: false,
        profession: false,
        club: false,
        website: false,
        userImg: false
    });
    const [img, setImg] = useState(null);
    const [userId, setUserId] = useState(null);

    const dispatch = useDispatch();
    const history = useHistory();

    const loadingAthlete = useSelector(state => state.Athlete.loading);
    const loading = useSelector(state => state.ExternalUser.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);
    const externalUserDetail = useSelector(state => state.ExternalUser.externalUserDetail);

    useEffect(() => {
        if(props.match && props.match.params && props.match.params.id) {
            dispatch(getExternalUserDetail(props.match.params.id));
        }
    }, [props, dispatch])

    useEffect(() => {
        dispatch(getAthletesList());
    }, [dispatch]);

    useEffect(() => {
        if(externalUserDetail) {
            const {address, city, current_club, email, first_name, id, image, last_name, position, postal, website, permission, athletes } = externalUserDetail;
            setForm({
                firstName: first_name || '',
                lastName: last_name  || '',
                address: address  || '',
                postal: postal  || '',
                city: city  || '',
                email: email  || '',
                profession: position  || '',
                club: current_club  || '',
                website: website  || '',
                athletes: athletes || [],
                permission: permission || {}
            })
            setUserId(id);
            if(image) {
                const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
                setImg({
                    file: image,
                    name: image.filename,
                    base64: `${mediaUrl}/avatar/${image.filename}.${image.extension}`,
                    isPreview: acceptedImageTypes.includes(image.mime_type),
                    size: (image.size / (1024 * 1024)).toFixed(2)
                });
            }
        }
    }, [externalUserDetail])

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const getFormattedImage = (file) => {
        const fileReader = new FileReader();
        return new Promise(resolve => {
            fileReader.readAsDataURL(file);
            fileReader.onload = (e) => {
                resolve(e.target.result);
            }
        });
    };

    const handleFileSelect = (e) => {
        if (e.target.files) {
            const file = e.target.files[ 0 ];
            if (!(file.type.split('/')[0] === 'image')) {
                alert('please upload valid image format');
            } else {
                const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
                if(!(bytesToMegaBytes(file.size) > 2)) {
                    setValid({ ...valid, userImg: true });
                    const reader = new FileReader();
                    reader.readAsDataURL(e.target.files[ 0 ]);
                    getFormattedImage(file).then(response => {
                        setImg({
                            file: file,
                            name: file.name,
                            base64: response,
                            isPreview: acceptedImageTypes.includes(file.type),
                            size: (file.size / (1024 * 1024)).toFixed(2)
                        });
                    });
                    setForm({
                        ...form,
                        userImg: e.target.files[ 0 ]
                    });
                } else {
                    alert('please upload file size less 2mb.');
                }
            }
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateCreateOrEditExternalUser(form);
        setErrors(errors);
        if(isValid) {
            dispatch(createOrEditExternalUser({
                form,
                callback: () => history.goBack(),
                id: userId
            }))
        }
    };

    const handleSelect = (value) => {
        if(!form.athletes.includes(value)) {
            setForm({
                ...form,
                athletes: [...form.athletes, value]
            });
        } else {
            let temPermission = Object.assign({}, form.permission);
            temPermission[value] = [];
            setForm({
                ...form,
                athletes: form.athletes.filter((e)=>(e !== value)),
                permission : temPermission
            })
        }
    }

    const handleSelectPermission = (data) => {    
       let temPermission = Object.assign({}, form.permission);
       if(temPermission.hasOwnProperty(data.id)) {
           if(temPermission[data.id].includes(data.name)) {
               temPermission[data.id] = temPermission[data.id].filter(e=> e !== data.name)
               setForm({
                   ...form,
                   permission : temPermission
               });
           } else {
               temPermission[data.id].push(data.name);
               setForm({
                   ...form,
                   permission : temPermission
               });
           }
       } else {
           temPermission[data.id] = [data.name];
           setForm({
               ...form,
               permission : temPermission
           });
       }
    };

    return (
        <>
            {(loadingAthlete || loading) && <Loader/>}
            <div className='athletes-edit'>
                <Banner
                    title={userId ? 'Edit external user' : 'Create new external'}
                    backText='External'
                    backUrl='/externals'
                    backClick={() => dispatch(resetExternalUserDetail())}
                />
                <div className='card m-3'>
                    <div className="row px-3 py-5">
                        <div className="col-lg-6 col-12 px-5">
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <Input
                                        label='First name'
                                        className={errors.firstName ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='firstName'
                                        value={form.firstName}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, firstName: e.target.value.trim().length >= 3});
                                            setErrors({ ...errors, firstName: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.firstName}
                                        maxLength={20}
                                    />
                                </div>
                                <div className="form-group col-md-6">
                                    <Input
                                        label='Last name'
                                        className={errors.lastName ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='lastName'
                                        value={form.lastName}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, lastName: e.target.value.trim().length >= 3});
                                            setErrors({ ...errors, lastName: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.lastName}
                                        maxLength={20}
                                    />
                                </div>
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Address'
                                    className={errors.address ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='address'
                                    value={form.address}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, address: e.target.value.trim().length >= 3});
                                        setErrors({ ...errors, address: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.address}
                                    maxLength={100}
                                />
                            </div>
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <Input
                                        label='Postal'
                                        className={errors.postal ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='postal'
                                        value={form.postal}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, postal: true});
                                            setErrors({ ...errors, postal: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.postal}
                                    />
                                </div>
                                <div className="form-group col-md-6">
                                    <Input
                                        label='City'
                                        className={errors.city ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='city'
                                        value={form.city}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, city: true});
                                            setErrors({ ...errors, city: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.city}
                                        maxLength={50}
                                    />
                                </div>
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Email'
                                    className={errors.email ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='email'
                                    value={form.email}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, email: validator.isEmail(e.target.value)});
                                        setErrors({ ...errors, email: false });
                                    }}
                                    type='email'
                                    required={true}
                                    errorMsg={errors && errors.email}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Profession'
                                    className={errors.profession ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='profession'
                                    value={form.profession}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, profession: true});
                                        setErrors({ ...errors, profession: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.profession}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Club'
                                    className={errors.club ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='club'
                                    value={form.club}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, club: true});
                                        setErrors({ ...errors, club: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.club}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Website'
                                    className='form-control'
                                    name='website'
                                    value={form.website}
                                    onChange={handleChange}
                                    type='text'
                                    maxLength={50}
                                />
                            </div>
                            <div className='form-group'>
                                <div className='input-with-label'>
                                    <label className='f-16 mb-2'>Athletes</label>
                                </div>
                                {
                                    athletesList && athletesList.map((itm, key) =>
                                        <div className="row" key={key}>
                                            <div className="col-md-5 col-12 py-3">
                                                <div className="form-check">
                                                    <input
                                                        className="form-check-input"
                                                        type="checkbox"
                                                        value={itm.id}
                                                        checked={form.athletes.includes(itm.id)}
                                                        onClick={() => handleSelect(itm.id)}
                                                        id={key}
                                                    />
                                                    <label className="form-check-label" htmlFor={key}>
                                                        {itm.first_name}
                                                    </label>
                                                </div>
                                            </div>
                                            {
                                                form.athletes.includes(itm.id) &&
                                                <div className="col-md-7 col-12 py-3">
                                                    <div className="row">
                                                        <div className="col">
                                                            <div 
                                                                className="form-check"
                                                                onClick={() => handleSelectPermission({
                                                                    id: itm.id,
                                                                    name: 'marketing'
                                                                })}
                                                            >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="checkbox"
                                                                    value="marketing"
                                                                    checked={form.permission[itm.id]  && form.permission[itm.id].includes('marketing')}
                                                                    name='marketing'
                                                                />
                                                                <label className="form-check-label" htmlFor='marketing'>
                                                                    Marketing
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="col">
                                                            <div 
                                                                className="form-check" 
                                                                onClick={() => handleSelectPermission({
                                                                    id: itm.id,
                                                                    name: 'legal'
                                                                })}
                                                            >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="checkbox"
                                                                    value="legal"                                                                
                                                                    checked={form.permission[itm.id]  && form.permission[itm.id].includes('legal')}
                                                                    name='legal'
                                                                />
                                                                <label className="form-check-label" htmlFor='legal'>
                                                                    Legal
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="col">
                                                            <div 
                                                                className="form-check"
                                                                onClick={() => handleSelectPermission({
                                                                    id: itm.id,
                                                                    name: 'branding'
                                                                })}
                                                            >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="checkbox"
                                                                    value="branding"                                                                
                                                                    checked={form.permission[itm.id]  && form.permission[itm.id].includes('branding')}
                                                                    name='branding'
                                                                />
                                                                <label className="form-check-label" htmlFor='branding'>
                                                                    Branding
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="col">
                                                            <div 
                                                                className="form-check"
                                                                onClick={() => handleSelectPermission({
                                                                    id: itm.id,
                                                                    name: 'highlights'
                                                                })}
                                                            >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="checkbox"
                                                                    value="highlights"
                                                                    checked={form.permission[itm.id]  && form.permission[itm.id].includes('highlights')}
                                                                    name='highlights'
                                                                />
                                                                <label className="form-check-label" htmlFor='highlights'>
                                                                    Highlights
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="col">
                                                            <div 
                                                                className="form-check"
                                                                onClick={() => handleSelectPermission({
                                                                    id: itm.id,
                                                                    name: 'medical'
                                                                })}
                                                            >
                                                                <input
                                                                    className="form-check-input"
                                                                    type="checkbox"
                                                                    value="medical"
                                                                    checked={form.permission[itm.id]  && form.permission[itm.id].includes('medical')}
                                                                    name='medical'
                                                                />
                                                                <label className="form-check-label" htmlFor='medical'>
                                                                    Medical
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    )
                                }
                            </div>
                         </div>
                        <div className="col-lg-6 col-12 px-5">
                            <div className="form-group image">
                                <div>
                                    <label htmlFor='userImg' className='f-14'>
                                        Profile image
                                    </label>
                                </div>
                                <div
                                    className="file-upload"
                                    onDragOver={() => setDragEnterExit(!isDragEnterExit)}
                                    onDragEnd={handleFileSelect}
                                    onChange={(e) => handleFileSelect(e)}
                                >
                                    <input type="file" accept="image/*"/>
                                    <div className="d-flex flex-wrap justify-content-center p-3">
                                        {img &&
                                        <div className="used-area m-3">
                                            {img.isPreview ?
                                                <div className="bg">
                                                    <button onClick={() => setImg(null)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <img alt={img.name} className="img-fluid preview" src={img.base64}/>
                                                    <div className="overlay">
                                                        <span className="size">{img.size} MB</span>
                                                        <div className="file-name mt-2">
                                                            <span className="name">{img.name}</span>
                                                        </div>
                                                    </div>
                                                </div> :
                                                <div className="no-preview">
                                                    <button onClick={() => setImg(null)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <span className="size">{img.size} MB</span>
                                                    <div className="file-name mt-2">
                                                        <span className="name">{img.name}</span>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                        }
                                    </div>
                                    {!img && <p>Drop files here or click to upload.</p>}
                                </div>
                                <p className='text-danger mt-2'>Upload only PNG, JPG, JPEG files and Maximum file size is 2 MB.</p>
                            </div>
                        </div>
                    </div>
                    <div className='text-center stick-at-bottom'>
                        <button
                            className='btn btn-global mx-5 my-3 f-14 cursor-pointer mt-3'
                            onClick={handleSubmit}
                        >
                            {userId ? 'Edit external user' : 'Add external user'}
                        </button>
                    </div>
                </div>
            </div>

        </>
    );
};

CreateOrEditExternalUser.propTypes = {
    match: PropTypes.shape({
        params: PropTypes.object,
    })
};

export default CreateOrEditExternalUser;

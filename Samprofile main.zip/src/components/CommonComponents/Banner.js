import React from 'react';
import PropTypes from 'prop-types';
import {Link} from 'react-router-dom';

import {useWindowSize} from "../../utils/helper";

const Banner = ({
  title,
  RedirectTo,
  buttonText,
  backUrl,
  backText,
  count,
  goalRedirect,
  goalBannerText,
  isGoal,
  isBranding,
  setCreateOrEditGoalOpen,
  classNames,
  backClick,
  isMarketingOrHighlight,
  buttonClick,
  setAddOpen,
  isDeteteFolder,
  handleDelete,
  handleDownloadZip,
  setIsCreateNewEvent,
  isEvent,
  isGreen
}) => {
  const [width] = useWindowSize();

    return (
    <div className="bannerBox">
      <div className="overlay">
        { width <= 767 &&
            backUrl && backText && (
          <div className="d-flex justify-content-between float-lg-left mt-lg-5 ml-md-5 mr-md-5 mt-md-0 ml-2 mr-2 mt-0 mb-2 pt-5 pt-lg-0">
            <Link
              className="m-2 text-white"
              to={backUrl}
              onClick={() => backClick()}
            >
                <svg
                    width="1em"
                    height="1em"
                    viewBox="0 0 16 16"
                    className="bi bi-chevron-left mb-1"
                    fill="currentColor"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
                </svg>
                <span>Back to {backText}</span>
            </Link>
          </div>
        )}
        <div className="d-flex justify-content-between float-lg-right mt-lg-5 ml-md-5 mr-md-5 mb-md-5 mt-md-0 ml-2 mr-2 mt-0 mb-2 pt-5 pt-lg-0">
          <Link className="ml-lg-5 m-2 text-white" to="/calender">
              <svg
                  width="1em"
                  height="1em"
                  viewBox="0 0 16 16"
                  className="bi bi-calendar-fill mb-1"
                  fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg"
              >
                  <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5h16V4H0V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5z"/>
              </svg>
              <span className="ml-2">Calendar</span>
          </Link>
        </div>
        <div className="bannerBottom">
          <h1 className={`bannerHeading ${classNames}`}>
            {title} <br className="d-block d-lg-none" />
            {isGoal && (
              <Link
                to={goalRedirect}
                className="f-16 pl-lg-4 pl-0 text-decoration-none text-white"
              >
                {goalBannerText}
                {count > 0 && (
                  <span className="rounded-pill pl-2 pr-2 ml-2 primary-bg-color">
                    {count}
                  </span>
                )}
              </Link>
            )}
          </h1>
          <div className="banner-button font-weight-bold">
            {
                isBranding &&(
              <>
                <button
                  className="customBtn btn f-16 cursor-pointer"
                  onClick={setAddOpen}
                >
                  Add folder
                </button>
                {isDeteteFolder && (
                  <button
                    className="customBtn btn f-16 cursor-pointer"
                    onClick={handleDelete}
                  >
                    Delete folder
                  </button>
                )}
                {
                  width > 767 && <button
                      className="customBtn btn f-16 cursor-pointer"
                      onClick={handleDownloadZip}
                  >
                    Download ZIP
                  </button>
                }
              </>
            )}
            {isGoal ? (
              <button
                className="btn customBtn f-16 cursor-pointer"
                onClick={() =>
                  isEvent
                    ? setIsCreateNewEvent(true)
                    : setCreateOrEditGoalOpen(true)
                }
              >
                {buttonText}
              </button>
            ) : isMarketingOrHighlight ? (
              <button
                className={
                  buttonText ? "btn customBtn f-16 cursor-pointer" : ""
                }
                onClick={(e) => buttonClick(e)}
              >
                {buttonText}
              </button>
            ) : (
                <Link
                    className={isGreen ? 'greeBtn f-16 cursor-pointer':'customBtn f-16 cursor-pointer'}
                    to={ RedirectTo? RedirectTo : ''}
                    onClick={() => backClick()}
                >
                    {buttonText}
                </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

Banner.propTypes = {
  title: PropTypes.string,
  RedirectTo: PropTypes.string,
  buttonText: PropTypes.string,
  backUrl: PropTypes.string,
  backText: PropTypes.string,
  isBranding: PropTypes.bool,
  isGoal: PropTypes.bool,
  setCreateOrEditGoalOpen: PropTypes.func,
  goalRedirect: PropTypes.string,
  goalBannerText: PropTypes.string,
  count: PropTypes.number,
  backClick: PropTypes.func,
  isMarketingOrHighlight: PropTypes.bool,
  buttonClick: PropTypes.func,
  setAddOpen: PropTypes.func,
  isDeteteFolder: PropTypes.bool,
  handleDelete: PropTypes.func,
  handleDownloadZip: PropTypes.func,
  setIsCreateNewEvent: PropTypes.func,
  isEvent: PropTypes.bool,
};

export default Banner;
import React, {Component} from 'react';
import DateRangePicker from 'react-bootstrap-daterangepicker';

class DateRangePickerCom extends Component {

    handleApply = (event, picker) => {
        picker.element.val(
            picker.startDate.format('D MMM YYYY') +
            ' - ' +
            picker.endDate.format('D MMM YYYY')
        );

        this.props.handleDateFilter({
            start: picker.startDate.format('DD/MM/YYYY'),
            end: picker.endDate.format('DD/MM/YYYY')
        })
    };

    render() {
        return (
            <div>
                <DateRangePicker
                    initialSettings={{
                        autoUpdateInput: false,
                        locale: {
                            cancelLabel: 'Cancel',
                        },
                    }}
                    onApply={this.handleApply}
                >
                    <input type="text" className="form-control" onKeyDown={e => e.preventDefault()} defaultValue="" placeholder="Select Date Range" />
                </DateRangePicker>
            </div>
        );
    }
}

export default DateRangePickerCom;
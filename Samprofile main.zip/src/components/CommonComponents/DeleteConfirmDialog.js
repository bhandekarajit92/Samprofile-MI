import React from 'react';
import PropTypes from 'prop-types';

const DeleteConfirmDialog = ({isDeleteOpen, setDeleteOpen, handleDelete}) => {
    return (
        <div className={isDeleteOpen ? "modal fade show d-block" : "d-none"}>
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                    <svg
                        width="2em"
                        height="2em"
                        viewBox="0 0 16 16"
                        className="bi bi-x cursor-pointer"
                        fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        onClick={() => setDeleteOpen(false)}
                    >
                        <path fillRule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                    </svg>
                    <div className='px-lg-5 py-4'>
                        <p className='text-center f-22'>Confirm</p>
                        <p className='text-center f-16'>Are you sure you want to delete this record?</p>
                        <div className='text-center'>
                            <button
                                className='btn btn-secondary px-4 py-2'
                                onClick={() => setDeleteOpen(false)}
                            >
                                Cancel
                            </button>
                            <button
                                className='btn btn-danger px-4 py-2 ml-2'
                                onClick={() => handleDelete()}
                            >
                                Ok
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

DeleteConfirmDialog.propTypes = {
    isDeleteOpen: PropTypes.bool,
    setDeleteOpen: PropTypes.func,
    handleDelete: PropTypes.func
};

export default DeleteConfirmDialog;
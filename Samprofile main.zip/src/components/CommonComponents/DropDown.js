import React from 'react';
import PropTypes from 'prop-types';

const DropDown = ({dropDownHeading, dropDownSelected, dropDownOption, onselect, name, value}) => {
    return (
        <>
            <label
                className="f-14 mb-2 mt-lg-4 mt-2 align-self-center"
            >
                {dropDownHeading}
                {'\u00A0'}{'\u00A0'}
            </label>
            <span className="mb-2 mt-lg-4 mt-2">
                <select
                    name={name}
                    onChange={onselect}
                    value={value}
                    className="bg-transparent border-0 f-18 cursor-pointer"
                >
                    <option value="">
                        {dropDownSelected}{'\u00A0'}{'\u00A0'}
                    </option>
                    {dropDownOption.map((option, index) =>
                        <option key={index} value={option.value}>
                            {option.name}
                        </option>
                    )}
                </select>
            </span>
        </>
    );
};

DropDown.propTypes = {
    dropDownHeading: PropTypes.object,
    dropDownSelected: PropTypes.string,
    dropDownOption: PropTypes.array,
    name: PropTypes.string,
    value: PropTypes.string,
    onselect: PropTypes.func
};

export default DropDown;

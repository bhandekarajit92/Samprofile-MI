import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";
import {useHistory} from 'react-router-dom';
import {Editor} from '@tinymce/tinymce-react';
import PropTypes from "prop-types";

import {Banner, DeleteConfirmDialog, Loader, Input} from '../CommonComponents';
import {
    createOrEditHighlights,
    deleteHIGHLIGHTS,
    getAthletesList,
    getHIGHLIGHTSDetail,
    getUsersList, resetHIGHLIGHTSDetail
} from "../../redux/action";
import validateCreateOrEditHighlights from "../../validations/highlightsValidation";
import {getUser, time_ago} from "../../utils/helper";

const CreateOrEditHighlights = (props) => {

    const [form, setForm] = useState({
        type: '',
        title: '',
        contents: '',
        raw_contents: '',
        pic: '',
        created_for: '',
        status: '',
        position: '',
        externals: []
    });
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        type: false,
        title: false,
        contents: false,
        raw_contents: false,
        pic: false,
        created_for: false,
        status: false,
        position: false,
        externals: false
    });

    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] = useState(null);
    const [highlightId, setHighlightId] = useState(null);

    const athletesList = useSelector(state => state.Athlete.athletesList);
    const usersList = useSelector(state => state.ExternalUser.usersList);
    const highlightsDetail = useSelector(state => state.Highlights.highlightsDetail);
    const loading = useSelector(state => state.Highlights.loading);

    const dispatch = useDispatch();
    const history = useHistory();

    useEffect(() => {
        if (props.match && props.match.params && props.match.params.id) {
            dispatch(getHIGHLIGHTSDetail(props.match.params.id));
        }
    }, [props, dispatch]);

    useEffect(() => {
        if (highlightsDetail && highlightsDetail.data && highlightsDetail.data.hasOwnProperty('documents')) {
            const {documents: {id,type, title, contents, raw_contents, created_for, externals, status}} = highlightsDetail.data;
            setForm({
                type: type,
                title: title,
                contents: contents,
                raw_contents: raw_contents,
                pic: false,
                created_for: created_for ? created_for.toString() : '',
                status: status || 'draft',
                position: false,
                externals: externals || []

            });
            setHighlightId(id);
        }
    }, [highlightsDetail]);

    useEffect(() => {
        dispatch(getUsersList());
        dispatch(getAthletesList());
    }, [dispatch]);

    const handleDelete = () => {
        dispatch(deleteHIGHLIGHTS({
            id: deleteId,
            calBack: () => {
                setDeleteOpen(false);
                history.goBack()
            }
        }));
    };

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const handleEditorChange = (content) => {
        setForm({
            ...form,
            contents: content
        });
        setValid({...valid, contents: true});
        setErrors({...errors, contents: false});
    };

    const handleCheck = (value) => {
        if (!form.externals.includes(value)) {
            setForm({
                ...form,
                externals: [...form.externals, value]
            });
        } else {
            setForm({
                ...form,
                externals: form.externals.filter((e) => (e !== value)),
            })
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const {errors, isValid} = validateCreateOrEditHighlights(form);
        setErrors(errors);
        if (isValid) {
            dispatch(createOrEditHighlights({
                form,
                callback: () => history.goBack(),
                id: highlightId
            }));
        }
    };

    return (
        <>
            {loading && <Loader/>}
            {
                JSON.parse(getUser()).is_admin ?
                    <Banner
                        title={highlightId ? 'Edit highlights' : 'Create new highlights'}
                        backText='Highlights'
                        backUrl='/highlights'
                        buttonText={highlightId? '' : 'Create'}
                        backClick={() => dispatch(resetHIGHLIGHTSDetail())}
                        isMarketingOrHighlight={true}
                        buttonClick={handleSubmit}
                    /> :
                    <Banner
                        title='View highlights'
                        backText='Highlights'
                        backUrl='/highlights'
                        backClick={() => console.log('')}
                    />
            }
            <div className="container-fluid create-or-edit-highlights">
                <div className="row mt-5 mb-5">
                    <div className="col-12 col-lg-8 mb-3 mb-lg-0">
                        <div className="title mb-3">
                            <Input className="title-input pl-3 pr-3  line-height-48 w-100 border-0"
                                   name='title'
                                   maxLength={50}
                                   value={form.title}
                                   onChange={(e) => {
                                       handleChange(e);
                                       setValid({...valid, title: e.target.value.trim().length >= 3});
                                       setErrors({...errors, title: false});
                                   }}
                                   errorMsg={errors && errors.title}
                                   type="text"
                                   placeholder="Highlights title"
                                   disabled={!JSON.parse(getUser()).is_admin}
                            />
                        </div>
                        <Editor
                            value={form.contents}
                            init={{
                                height: 500,
                                menubar: false,
                                plugins: [
                                    'media mediaembed',
                                ],
                                toolbar:
                                    'media mediaembed'
                            }}
                            onEditorChange={handleEditorChange}
                            disabled={!JSON.parse(getUser()).is_admin}
                        />
                        <div className="invalid-feedbacks">
                            {errors && errors.contents}
                        </div>
                    </div>
                    <div className="col-12 col-lg-4 mb-3 mb-lg-0">
                        <form className="bg-white p-4">
                            <h2 className="f-24 light-dark pb-2">Publishing</h2>
                            <strong className="montserrat-bold f-16">Created by</strong>
                            <p className="light-dark f-16 pt-0 pb-2">Super User {highlightsDetail  && highlightsDetail.data ? time_ago(highlightsDetail.data.documents.created_at) : '1 second ago '}</p>
                            <strong className="montserrat-bold f-16">Last edited</strong>
                            <p className="light-dark f-16 pt-0 pb-2">Super User {highlightsDetail  && highlightsDetail.data ? time_ago(highlightsDetail.data.documents.updated_at) : '1 second ago '}</p>
                            {
                                JSON.parse(getUser()).is_admin &&
                                    <>
                                        <p className="pb-2">
                                            <strong className="montserrat-bold f-16">Belongs to</strong><br/>
                                            {
                                                !highlightId ? <select
                                                        className="select bg-transparent light-dark line-height-24 cursor-pointer"
                                                        id="created_for"
                                                        name="created_for"
                                                        onChange={(e) => {
                                                            handleChange(e);
                                                            setValid({...valid, created_for: true});
                                                            setErrors({...errors, created_for: false});
                                                        }}
                                                        value={form.created_for}
                                                    >
                                                        <option>Select athlete</option>
                                                        {
                                                            athletesList && athletesList.length > 0 &&
                                                            athletesList.map(itm =>
                                                                <option value={itm.id} key={itm.key}>{itm.first_name}</option>
                                                            )
                                                        }
                                                    </select> :

                                                    <p>{athletesList && athletesList.length > 0 && athletesList.find(itm => (itm.id).toString() === form.created_for).first_name}
                                                        {form.created_for}

                                                    </p>
                                            }
                                            <div className="invalid-feedbacks">
                                                {errors && errors.created_for}
                                            </div>
                                        </p>
                                        <p className="pb-2">
                                            <strong className="montserrat-bold f-16">Status</strong><br/>
                                            <select name="status"
                                                    onChange={handleChange}
                                                    value={form.status}
                                                    className="select bg-transparent light-dark line-height-24 cursor-pointer">
                                                <option value="draft" selected>Draft</option>
                                                <option value="published">Published</option>
                                            </select>
                                        </p>
                                        <strong className="montserrat-bold f-16">Externals</strong><br/>
                                        {usersList && usersList.length > 0 ?
                                            usersList.map((itm) =>
                                                    <span className="checkbox d-block">
                                                        <input
                                                            type="checkbox"
                                                            value={itm.id}
                                                            onChange={() => handleCheck((itm.id).toString())}
                                                            checked={form.externals.includes((itm.id).toString())}
                                                        />&nbsp;
                                                        {itm.first_name}
                                                    </span>
                                            ) : null
                                        }
                                    </>
                            }
                        </form>
                        {
                            JSON.parse(getUser()).is_admin &&
                            highlightId ?
                                <div className='line-height-48 border-top bg-white pl-4 pr-4 d-flex justify-content-between align-items-center delete-update-section'>
                                    <span onClick={() => {
                                        setDeleteOpen(true);
                                        setDeleteId(highlightId)
                                    }}
                                          className="light-red cursor-pointer"
                                    >
                                        <svg
                                            width="1em"
                                            height="1em"
                                            viewBox="0 0 16 16"
                                            className="bi bi-trash"
                                            fill="currentColor"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                                            <path fillRule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                                        </svg>
                                        Delete
                                    </span>
                                    <button
                                        onClick={handleSubmit}
                                        className="custom-btn text-decoration-none pl-4 pr-4 f-16 font-weight-bold border-0 rounded"
                                    >
                                        Update
                                    </button>
                                </div> : null
                        }
                    </div>
                </div>
            </div>
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />
        </>
    );
};

CreateOrEditHighlights.propTypes = {
    match: PropTypes.shape({
        params: PropTypes.object,
    })
};

export default CreateOrEditHighlights;

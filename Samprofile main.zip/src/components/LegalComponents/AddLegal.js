import React, {useEffect, useState} from 'react';
import {useHistory} from "react-router-dom";
import {useDispatch, useSelector} from "react-redux";
import $ from 'jquery';
import {toast} from "react-toastify";

import {Banner, DropDown, Loader} from '../CommonComponents'
import {getAthletesList, uploadLegal} from "../../redux/action";
import {ErrorToast} from "../../utils/helper";

const AddLegal = () => {
    const [theArray, setTheArray] = useState([]);
    const [athleteId, setAthleteId] = useState(null);
    const [isDragEnterExit, setDragEnterExit] = useState(false);
    const [athleteList, setAthleteList] = useState([]);

    const history = useHistory();
    const dispatch = useDispatch();

    const loading = useSelector(state => state.Legal.loading);
    const loadingAthlete = useSelector(state => state.Athlete.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);

    useEffect(() => {
        if (athletesList && athletesList.length > 0) {
            setAthleteList(athletesList.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [athletesList]);

    useEffect(() => {
        dispatch(getAthletesList());
    }, [dispatch]);

    useEffect(() => {
        if (theArray.length > 10) {
            setTheArray(theArray => theArray.slice(0, 10));
            toast.error(<ErrorToast msg='You can not upload more than 10 files.'/>);
        }
    }, [theArray]);

    const onSelect = (e) => {
        setAthleteId(e.target.value);
    };

    const getFormattedImage = (file) => {
        const fileReader = new FileReader();
        return new Promise(resolve => {
            fileReader.readAsDataURL(file);
            fileReader.onload = (e) => {
                resolve(e.target.result);
            }
        });
    };

    const handleFileSelect = (e) => {
        if (theArray.length < 10) {
            const files = e.target.files;
            const arrPromise = [];
            let arr = [];
            const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png'];
            for (const key in files) {
                if (files.hasOwnProperty(key)) {

                    if((files[key].size / (1024 * 1024)).toFixed(2) <= 2){
                        arrPromise.push(new Promise(resolve => {
                            getFormattedImage(files[key]).then(response => {
                                arr.push({
                                    file: files[key],
                                    name: files[key].name,
                                    base64: response,
                                    isPreview: acceptedImageTypes.includes(files[key].type),
                                    size: (files[key].size / (1024 * 1024)).toFixed(2)
                                });
                                resolve();
                            });
                        }))
                    }else{
                        toast.error(<ErrorToast msg='File size must not be more than 2 MB'/>)
                    }

                }
            }
            Promise.all(arrPromise).then(() => {
                setTheArray([...theArray, ...arr]);
                $('input[type="file"]').val(null);
            });
        } else {
            toast.error(<ErrorToast msg='You can not upload more than 10 files.'/>);
        }
    };

    const handleRemoveFile = (file) => {
        setTheArray(theArray => theArray.filter(item => item.base64 !== file.base64));
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if (athleteId && theArray.length !== 0) {
            const req = {id: athleteId, files: theArray.filter(itm => itm.file)};
            dispatch(uploadLegal({req, callback: () => history.goBack()}));
        } else if (!athleteId) {
            toast.error(<ErrorToast msg='Please select an athlete.'/>)
        }
    };

    return (
        <>
            {(loading || loadingAthlete) && <Loader/>}
            <div className="add-legal">
                <Banner
                    title='Upload legal file(s)'
                    backText='Legal'
                    backClick={() => {console.log('')}}
                    backUrl='/legal'
                />
                <div className="centerContainer">
                    <div className="filterBox w-100 d-block d-md-flex justify-content-between">
                        <div>
                            <DropDown
                                onselect={onSelect}
                                dropDownHeading='Attach file to athlete'
                                dropDownSelected='Select athlete'
                                dropDownOption={athleteList}
                                name='athlete'
                            />
                        </div>
                    </div>
                    <div className="folderBox d-block">
                        <div className="col-12">
                            <div className="file-upload" onDragOver={() => setDragEnterExit(!isDragEnterExit)} onDragEnd={handleFileSelect} onChange={handleFileSelect}>
                                <input type="file" multiple/>
                                <div className="d-flex  flex-wrap justify-content-center p-3">
                                    {theArray.map((item, key) =>
                                        <div key={key} className="used-area m-3">
                                            {item.isPreview ?
                                                <div className="bg">
                                                    <button onClick={() => handleRemoveFile(item)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <img alt={item.name} className="img-fluid preview" src={item.base64}/>
                                                    <div className="overlay">
                                                        <span className="size">{item.size} MB</span>
                                                        <div className="file-name mt-2">
                                                            <span className="name">{item.name}</span>
                                                        </div>
                                                    </div>
                                                </div> : <div className="no-preview">
                                                    <button onClick={() => handleRemoveFile(item)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <span className="size">{item.size} MB</span>
                                                    <div className="file-name mt-2">
                                                        <span className="name">{item.name}</span>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    )}
                                </div>
                                {theArray.length === 0 ? <p>Drop files here or click to upload.</p> : ''}
                            </div>
                        </div>
                    </div>
                    <div className='text-center'>
                        <button
                            onClick={handleSubmit}
                            className="btn btn-global mt-3 mr-3"
                            disabled={theArray.length === 0}
                        >
                            Save
                        </button>
                        <button
                            className="btn btn-global mt-3"
                            onClick={() => history.goBack()}
                        >
                            Cancel
                        </button>
                    </div>
                </div>
        </div>
        </>
    );
};
export default AddLegal;

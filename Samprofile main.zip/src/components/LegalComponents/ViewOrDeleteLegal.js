import React, {memo,useEffect, useState} from 'react';

import {useHistory} from 'react-router-dom';
import {Banner, DeleteConfirmDialog, Loader} from "../CommonComponents";
import {useDispatch, useSelector} from "react-redux";
import {deleteLEGAL, getLegalDetail} from "../../redux/action";
import {apiUrl, getToken, time_ago} from "../../utils/helper";

const ViewOrDeleteLegal = memo((props) => {

    const history = useHistory();
    const dispatch = useDispatch();
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] = useState(null);
    const legalDetail = useSelector(state => state.Legal.legalDetail);
    const [legalId, setLegalId] = useState(null);
    const loading = useSelector(state => state.Legal.loading);

    const [loadZip, setLoadZip] = useState(false);

    useEffect(() => {
        if (props.match && props.match.params && props.match.params.id) {
            setLegalId(props.match.params.id);
        }
    }, [props]);


    useEffect(()=>{
        if(legalId){
            dispatch(getLegalDetail(legalId));
        }
        },[legalId,dispatch])

    const handleDelete = () => {
        dispatch(deleteLEGAL({
            id: deleteId,
            callBack: () => {
                setDeleteOpen(false);
                history.goBack()
            }
        }));
    };


    const onDownloadFile = (type) => {

        console.log(type);
        setLoadZip(true);

        const requestOptions = {
            method: 'GET', headers: {
                'Authorization': `Bearer ${getToken()}`,
            }
        };
        fetch(`${apiUrl}legal/${legalId}/download`, requestOptions).then(response => response.blob()).then(res => {
            const blob = new Blob([res]);
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            if (type === 'view') {

                var image = new Image();
                image.src = url;
                var w = window.open("");
                w.document.write(image.outerHTML);
                w.document.close();
                setLoadZip(false);

            } else {
                link.href = url;
                link.setAttribute('download', legalDetail.file.custom_properties.original_name);
                document.body.appendChild(link);
                link.click();
                link.parentNode.removeChild(link);
                setLoadZip(false);
            }


        })
    }

    return (
        <>

            {(loading || loadZip) && <Loader/>}

            <Banner
                title='File info'
                backText='Legal'
                backUrl='/legal'
            />

            <div className="center-container">
                <div
                    className="info-box d-md-flex justify-content-center justify-content-md-start flex-md-row flex-column">
                    <div className="photo p-5">
                        <img src="https://dev.samprofiles.com/images/file.png" alt="file"/>
                    </div>


                    {legalDetail && legalDetail.file &&

                    <div className="text pl-5 pb-5 ml-0 ml-md-5 p-md-0">
                        <h3> {legalDetail.file.custom_properties.original_name}</h3>

                        <div>
                            <p className="pb-1 m-0">
                                <span>Uploaded by: </span>Super user {time_ago(legalDetail.file.updated_at)}<br/>
                            </p>
                            <p className="pb-1 m-0">
                                <span>Assigned to: </span>{legalDetail.file.assigned_to_name}<br/>
                            </p>
                            <p className="pb-1">
                                <span>size: </span>{legalDetail.file.size} Bytes
                            </p>
                        </div>

                        <div className="bottom">
                            <div>
                                <button className="view btn" onClick={() => {onDownloadFile('view')}} >View</button>
                                <button className="view btn" onClick={() => {onDownloadFile('download')}}>Download</button>
                                <button className="delete btn" onClick={() => {
                                    setDeleteOpen(true);
                                    setDeleteId(legalId)
                                }}>Delete
                                </button>
                            </div>
                        </div>
                    </div>

                    }


                </div>
            </div>

            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={handleDelete}
            />

        </>
    );
});

export default ViewOrDeleteLegal;


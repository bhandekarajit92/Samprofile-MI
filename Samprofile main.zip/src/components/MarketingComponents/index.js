export { default as CreateMarketing } from './CreateOrEditMarketing';

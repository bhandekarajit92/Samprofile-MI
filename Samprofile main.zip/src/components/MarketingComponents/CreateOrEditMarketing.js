import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {useHistory} from 'react-router-dom';
import PropTypes from 'prop-types';

import {Banner, RichTextEditor, Loader, DeleteConfirmDialog} from '../CommonComponents';
import {
    createOrEditMarketing,
    getMarketingDetail,
    resetMarketingDetail,
    getAthletesList,
    getUsersList,
    deleteMarketing
} from "../../redux/action";
import validateCreateOrEditMarketing from "../../validations/createOrEditMarketingValidation";
import {getUser, time_ago} from "../../utils/helper";

const CreateOrEditMarketing = (props) => {
    const [form, setForm] = useState({
        title: '',
        contents: '',
        created_for: '',
        status: 'draft',
        externals: []
    });
    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        title: false,
        contents: false,
        created_for: false,
        status: false,
        externals: false
    });
    const [marketingId, setMarketingId] = useState(null);
    const [isDeleteOpen, setDeleteOpen] = useState(false);
    const [deleteId, setDeleteId] = useState(null);

    const dispatch = useDispatch();
    const history = useHistory();

    const loadingAthlete = useSelector(state => state.Athlete.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);
    const loading = useSelector(state => state.Marketing.loading);
    const loadingExternal = useSelector(state => state.ExternalUser.loading);
    const externalUsersList = useSelector(state => state.ExternalUser.usersList);
    const marketingDetail = useSelector(state => state.Marketing.marketingDetail);

    useEffect(() => {
        dispatch(getAthletesList());
        dispatch(getUsersList());
    }, [dispatch]);

    useEffect(() => {
        if(props.match && props.match.params && props.match.params.id) {
            dispatch(getMarketingDetail(props.match.params.id));
        }
    }, [props, dispatch])

    useEffect(() => {
        if(marketingDetail && marketingDetail.hasOwnProperty('documents')) {
            const {documents : {id, title, contents, created_for, status, externals}} = marketingDetail;
            setForm({
                title: title || '',
                contents: contents || '',
                created_for: created_for ? created_for.toString() : '',
                status: status || 'draft',
                externals: externals || []
            })
            setMarketingId(id)
        }
    }, [marketingDetail])

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const handleReachTextChange = (data) => {
        setForm({
            ...form,
            contents: data
        })
        setValid({ ...valid, contents: true});
        setErrors({ ...errors, contents: false });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateCreateOrEditMarketing(form);
        setErrors(errors);
        if(isValid){
            dispatch(createOrEditMarketing({
                form,
                callback: () => history.goBack(),
                id: marketingId
            }));
        }
    };

    const handleCheck = (value) => {
        if(!form.externals.includes(value)) {
            setForm({
                ...form,
                externals: [...form.externals, value]
            });
        } else {
            setForm({
                ...form,
                externals: form.externals.filter((e)=>(e !== value)),
            })
        }
    };

    const handleDelete = () => {
        dispatch(deleteMarketing({
            id: deleteId,
            callback: () => {
                setDeleteOpen(false);
                history.push('/marketing')
            }
        }))
    }

 return (
    <>
        {(loadingAthlete || loading || loadingExternal) && <Loader/>}
        <div className="marketing-create">
            {
                JSON.parse(getUser()).is_admin ?
                <Banner
                    title={marketingId ? 'Edit marketing plan' : 'Create new marketing plan'}
                    backText='Marketing'
                    backUrl='/marketing'
                    buttonText={marketingId ? '' : 'Create'}
                    backClick={() => dispatch(resetMarketingDetail())}
                    isMarketingOrHighlight={true}
                    buttonClick={handleSubmit}
                />:
                    <Banner
                        title='View marketing plan'
                        backText='Marketing'
                        backUrl='/marketing'
                        backClick={() => console.log('')}
                    />
            }
            <div className="center-container">
                <div className="row px-2 py-3">
                    <div className="col-md-12 col-lg-7 col-12">
                          <div className="title">
                              <input
                                  id='title'
                                  type='text'
                                  placeholder='Marketing plan title'
                                  disabled={!JSON.parse(getUser()).is_admin}
                                  name='title'
                                  className={errors.title ?
                                      'form-control is-invalid' : 'form-control'
                                  }
                                  value={form.title}
                                  onChange={(e) => {
                                      handleChange(e);
                                      setValid({ ...valid, title: e.target.value.trim().length >= 3});
                                      setErrors({ ...errors, title: false });
                                  }}
                                  maxLength={50}
                              />
                              <div className="invalid-feedback">
                                  {errors && errors.title}
                              </div>
                          </div>
                        <div className='mt-3'>
                            <RichTextEditor
                                handleChange={handleReachTextChange}
                                disabled={!JSON.parse(getUser()).is_admin}
                                value={form.contents}
                            />
                            <div className="error-content">
                                {errors && errors.contents}
                            </div>
                        </div>
                    </div>
                    <div className="col-md-12 col-lg-5 col-12 mt-2 mt-md-0">
                        <div className="publish-box">
                            <div className="inner py-3">
                                <h2>Publishing</h2>
                                <div className="col-list">
                                    <div className="list">
                                        <strong>Created by</strong>
                                        <p>Super User {marketingDetail  && marketingDetail.documents && marketingDetail.documents.created_at ? time_ago(marketingDetail.documents.created_at) : '1 second ago '}</p>
                                    </div>
                                    <div className="list">
                                        <strong>Last edited</strong>
                                        <p>Super User {marketingDetail  && marketingDetail.documents && marketingDetail.documents.updated_at ? time_ago(marketingDetail.documents.updated_at) : '1 second ago '}</p>
                                    </div>
                                    {
                                        JSON.parse(getUser()).is_admin &&
                                        <>
                                            <div className="list">
                                                <strong>Belongs to</strong>
                                                {
                                                    !marketingId ? <span className="select">
                                                            <select
                                                                id="created_for"
                                                                name="created_for"
                                                                onChange={(e) => {
                                                                    handleChange(e);
                                                                    setValid({...valid, created_for: true});
                                                                    setErrors({...errors, created_for: false});
                                                                }}
                                                                value={form.created_for}
                                                            >
                                                                <option>Select athlete</option>
                                                                {
                                                                    athletesList && athletesList.length > 0 &&
                                                                    athletesList.map(itm =>
                                                                        <option value={itm.id}
                                                                                key={itm.key}>{itm.first_name}</option>
                                                                    )
                                                                }
                                                            </select>
                                                        </span> :
                                                        <p>{athletesList && athletesList.find(itm => (itm.id).toString() === form.created_for).first_name}</p>
                                                }
                                                <div className="error-content">
                                                    {errors && errors.created_for}
                                                </div>
                                            </div>
                                            <div className="list">
                                                <strong>Status</strong>
                                                <span className="select">
                                                    <select
                                                        name="status"
                                                        onChange={(e) => handleChange(e)}
                                                        value={form.status}
                                                    >
                                                        <option value="draft" selected="selected">Draft</option>
                                                        <option value="published">Published</option>
                                                    </select>
                                                </span>
                                            </div>
                                            <div className="list list-checkbox">
                                                <strong>Externals</strong>
                                                <div className="checkbox-list">
                                                    {
                                                        externalUsersList && externalUsersList.length > 0 &&
                                                        externalUsersList.map(itm =>
                                                            <div className="checkbox-item external-user-permissions" key={itm.id}>
                                                                <span className="checkbox cursor-pointer" onClick={() => handleCheck((itm.id).toString())}>
                                                                    <input
                                                                        type="checkbox"
                                                                        value={itm.id}
                                                                        checked={form.externals.includes((itm.id).toString())}
                                                                    />&nbsp;
                                                                    {itm.first_name}
                                                                </span>
                                                            </div>
                                                        )
                                                    }
                                                </div>
                                            </div>
                                        </>
                                    }
                                    {
                                        marketingId && <div className="list">
                                            <button className="button btn">Export as PDF</button>
                                        </div>
                                    }
                                </div>
                            </div>
                            {
                                JSON.parse(getUser()).is_admin &&
                                marketingId && <div className="bottom">
                                    <div>
                                        <button className="delete btn" onClick={() => {
                                            setDeleteOpen(true);
                                            setDeleteId(marketingId);
                                        }}>Delete</button>
                                        <button className="update btn" onClick={(e) => handleSubmit(e)}>Update</button>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <DeleteConfirmDialog
            isDeleteOpen={isDeleteOpen}
            setDeleteOpen={setDeleteOpen}
            handleDelete={handleDelete}
        />
    </>
 );
};

CreateOrEditMarketing.propTypes = {
    match: PropTypes.shape({
        params: PropTypes.object,
    })
};

export default CreateOrEditMarketing;

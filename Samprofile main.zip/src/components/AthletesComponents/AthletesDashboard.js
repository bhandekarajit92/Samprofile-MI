import React, {Fragment, useEffect, useState} from 'react';
import {Link} from "react-router-dom";
import {useDispatch, useSelector} from 'react-redux';

import {Banner, DateRangePickerCom, Loader} from '../CommonComponents';
import {CreateOrEditGoals} from "../GoalsComponents";
import {
    getAthleteDashboardData,
    getHighlightsList,
    getLegalList,
    getMarketingList,
    sendMessage, viewGoalsList
} from "../../redux/action";
import {getUser, mediaUrl} from "../../utils/helper";
import Avatar from "../../assets/images/userImg.jpeg";

const CreateOrEditAthletes = (props) => {
    const [isCreateOrEditGoalOpen, setCreateOrEditGoalOpen] = useState(false);
    const [content, setContent] = useState('');
    const [id, setAthleteId] = useState(null);
    const [goalEditId, setEditGoalId] =  useState(null);

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Athlete.loading);
    const athleteDashboardData = useSelector(state => state.Athlete.athleteDashboardData);
    const loadingMarketing = useSelector(state => state.Marketing.loading);
    const marketingList = useSelector(state => state.Marketing.marketingList);
    const loadingHighlight = useSelector(state => state.Highlights.loading);
    const highlightList = useSelector(state => state.Highlights.highlightList);
    const loadingLegal = useSelector(state => state.Legal.loading);
    const legalList = useSelector(state => state.Legal.legalList);
    const loadingGoal =useSelector(state => state.Goals.loading);
    const goalsData = useSelector(state => state.Goals.goalsList);

    useEffect(() => {
        console.log(props)
        if(props && props.match && props.match.params && props.match.params.id) {
            dispatch(getAthleteDashboardData(props.match.params.id))
            dispatch(getMarketingList({
                show_docs_for: props.match.params.id
            }))
            dispatch(getHighlightsList({
                show_docs_for: props.match.params.id
            }))
            dispatch(getLegalList({
                athlete_id: props.match.params.id
            }))
            dispatch(viewGoalsList());
        } else if(!JSON.parse(getUser()).is_admin) {
            dispatch(getAthleteDashboardData(JSON.parse(getUser()).id))
            dispatch(getMarketingList({
                show_docs_for: JSON.parse(getUser()).id
            }))
            dispatch(getHighlightsList({
                show_docs_for: JSON.parse(getUser()).id
            }))
            dispatch(getLegalList({
                athlete_id: JSON.parse(getUser()).id
            }))
            dispatch(viewGoalsList());
        }
    }, [props, dispatch]);

    const  handleDateFilter = (data) => {
        dispatch(viewGoalsList(data))
    };

    return (
        <>
            {(loading || loadingMarketing || loadingHighlight || loadingLegal || loadingGoal) && <Loader/>}
            <div className="athletes-dashboard-banner position-relative">
                <div className='row athletes-dashboard-card border-radius position-absolute bg-white'>
                    <div className="col-5 card-img-box pl-0 pr-0">
                        <img
                            className="img-fluid border-radius w-100 h-100"
                            src={
                                athleteDashboardData &&
                                athleteDashboardData.user &&
                                athleteDashboardData.user.image ?
                                    `${mediaUrl}/avatar/${athleteDashboardData.user.image.filename}.${athleteDashboardData.user.image.extension}` :
                                    Avatar
                            }
                            alt="athlete"
                        />
                    </div>
                    <div className="col-4 col-lg-4 col-md-6 align-self-center card-container">
                        <div className="row justify-content-lg-between">
                            <div className="col-12 pl-0 pr-0 pt-0 pb-3 card-heading">
                                <h3 className="light-dark">
                                    {
                                        athleteDashboardData &&
                                        athleteDashboardData.user &&
                                        athleteDashboardData.user.first_name
                                    }
                                    <br className="d-none d-md-block d-lg-block" />
                                    {
                                        athleteDashboardData &&
                                        athleteDashboardData.user &&
                                        athleteDashboardData.user.last_name
                                    }
                                </h3>
                            </div>
                            <div className="col-12 pl-0 pr-0 pt-0 pb-3 card-content">
                                <p className="mb-0 f-16">
                                    <span className="">CLUB</span><br />
                                    {
                                        athleteDashboardData &&
                                        athleteDashboardData.user &&
                                        athleteDashboardData.user.current_club
                                    }
                                </p>
                            </div>
                            <div className="col-6 col-lg-4 col-md-4 pl-0 pr-0 pt-0 pb-3 card-content">
                                <p className="mb-0 f-16">
                                    <span className="">SPORT</span><br />
                                    {
                                        athleteDashboardData &&
                                        athleteDashboardData.user &&
                                        athleteDashboardData.user.sport
                                    }
                                </p>
                            </div>
                            <div className="col-6 col-lg-4 col-md-4 pl-0 pr-0 pt-0 pb-3 card-content">
                                <p className="mb-0 f-16">
                                    <span className="">POSITION</span><br />
                                    {
                                        athleteDashboardData &&
                                        athleteDashboardData.user &&
                                        athleteDashboardData.user.position
                                    }
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <Banner/>
            </div>
            <div className="athletes-dashboard position-relative">
                <div className="container-fluid">
                    <div className="row bg-white justify-content-lg-end pt-4 pb-3 m-lg-4 m-2">
                        <div className="col-lg-6 col-12 mb-md-2 md-0 text-center text-lg-left">
                            <h2 className="f-24">Your Goals {`\u00A0`}
                                <Link to='/goals' className="text-decoration-none cursor-pointer f-14 vertical-align-middle primary-color">See all</Link>
                            </h2>
                        </div>
                        <div className="col-lg-4 col-md-6 d-flex justify-content-lg-end justify-content-center align-self-center mb-lg-1 mb-0">
                            <DateRangePickerCom
                                handleDateFilter={handleDateFilter}
                            />
                            <img
                                className="img-fluid ml-3 align-self-center cursor-pointer"
                                src="https://dev.samprofiles.com/images/ic-autorenew-24-px.png"
                                alt='reset'
                                onClick={() => dispatch(viewGoalsList())}
                            />
                        </div>
                        <div className="col-lg-2 col-md-6 mt-lg-0 mt-md-0 mt-3 d-flex justify-content-center mb-lg-1 mb-0 align-items-center">
                            <input className="customBtn f-14 text-white pl-2 pr-2" type="button" value="Export as PDF"/>
                        </div>
                        {
                            athleteDashboardData && athleteDashboardData.user  && athleteDashboardData.user.id &&
                            <div className="col-12 mt-3 mb-3">
                                <div className="time-stepper">
                                    {
                                        goalsData &&
                                        goalsData.length > 0 &&
                                        goalsData.filter(itm => itm.athlete_id === athleteDashboardData.user.id) &&
                                        goalsData.filter(itm => itm.athlete_id === athleteDashboardData.user.id).length > 0 &&
                                        goalsData.filter(itm => itm.athlete_id === athleteDashboardData.user.id).map(item =>
                                            <div className="stepper-container" onClick={() => {
                                                setCreateOrEditGoalOpen(true);
                                                setAthleteId(item.athlete_id);
                                                setEditGoalId(item.id);
                                            }}>
                                                <div className="goal">
                                                    <div className="goal-title">
                                                        <div className="text-decoration-none f-24 cursor-pointer title-goal">
                                                            {item.title}
                                                        </div>
                                                        <div className="goal-start-date"> Started {item.start_date_h}</div>
                                                    </div>
                                                    <div className="goal-tip" />
                                                </div>
                                                <div className="goal-timeline"/>
                                                <div className="goal-timeline-circle"/>
                                                <div className="goal-due-date f-12">
                                                    {item.due_date_h}&nbsp;
                                                    <b>{item.due_date_time}</b>
                                                </div>
                                            </div>
                                        )
                                    }
                                    <div className="stepper-container">
                                        <div
                                            className="goal"
                                            style={{width:'176px',textAlign: 'center !important', paddingLeft:'0'}}
                                            onClick={() => setAthleteId(athleteDashboardData.user.id)}
                                        >
                                            <div className="text-center cursor-pointer" onClick={() => setCreateOrEditGoalOpen(true)}>
                                                <img src="https://dev.samprofiles.com/images/ic-add-circle.svg" width="26" height="26" alt={'img'} />
                                            </div>
                                            <div className="goal-title text-center cursor-pointer" onClick={() => setCreateOrEditGoalOpen(true)}>
                                                <p className="text-decoration-none f-22">Create</p>
                                            </div>
                                        </div>
                                        <div className="goal-tip invisible" />
                                        <div className="goal-timeline"/>
                                        <div className="goal-timeline-circle invisible"/>
                                        <div className="goal-due-date f-12 invisible">{`\u00A0`}</div>
                                    </div>
                                </div>
                            </div>
                        }
                    </div>
                    <div className="row mb-5">
                        <div className="col-12 col-lg-8">
                            <div className="pt-4 pb-3 padding-left-15 border-bottom ml-lg-4 mb-md-0 mr-lg-0 mt-lg-4 ml-2 mr-2 mt-2 mb-0 bg-white">
                                <h2 className="f-24">Documents</h2>
                            </div>
                            {/*Marketing*/}
                            <div className="padding-left-15 border-bottom ml-lg-4 mr-lg-0 mt-lg-0 mb-md-0 ml-2 mr-2 mt-0 mb-0 bg-white">
                                <div className="p-lg-3">
                                    <div className="d-flex justify-content-between">
                                        <h3 className="light-dark f-18 mt-2 mt-lg-0">
                                            Marketing
                                            <span className="counter-pill text-center f-12 d-inline-block primary-bg-color text-white">
                                                {marketingList && marketingList.documents && marketingList.documents.length}
                                            </span>
                                        </h3>
                                        <Link className="text-decoration-none hover-black-color vertical-align-middle primary-color pr-2 pr-lg-0" to='/marketing'>
                                            more
                                            <svg
                                                width="1em"
                                                height="1em"
                                                viewBox="0 0 16 16"
                                                className="bi bi-chevron-right"
                                                fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                                            </svg>
                                        </Link>
                                    </div>
                                    <div className='pl-0 pr-0 pl-lg-3 pr-lg-3'>
                                        <div className="card-custom-container">
                                            {
                                                marketingList && marketingList.documents && marketingList.documents.length > 0 &&
                                                marketingList.documents.map((itm,key) =>
                                                    <Fragment key={key}>
                                                        {
                                                            key <= 2 ?
                                                                <Link
                                                                    to={JSON.parse(getUser()).is_admin ? `/marketing/${itm.id}/edit` : `/marketing/${itm.id}/view`}
                                                                    className="card-custom mt-2 mb-2"
                                                                    key={key}
                                                                >
                                                                    <img src="https://dev.samprofiles.com/images/card.jpg" alt="marketing-icon" />
                                                                    <p className="doc-image-description f-12">{itm.title}</p>
                                                                </Link> :
                                                                null
                                                        }
                                                    </Fragment>
                                                )
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/*Highlights*/}
                            <div className="padding-left-15 border-bottom ml-lg-4 mr-lg-0 mt-lg-0 mb-md-0 ml-2 mr-2 mt-0 mb-0 bg-white">
                                <div className="p-lg-3">
                                    <div className="d-flex justify-content-between">
                                        <h3 className="light-dark f-18 mt-2 mt-lg-0">
                                            Highlights
                                            <span className="counter-pill text-center f-12 d-inline-block primary-bg-color text-white">
                                                {highlightList && highlightList.documents && highlightList.documents.length}
                                            </span>
                                        </h3>
                                        <Link to='/highlights' className="text-decoration-none hover-black-color vertical-align-middle primary-color pr-2 pr-lg-0">
                                            more
                                            <svg
                                                width="1em"
                                                height="1em"
                                                viewBox="0 0 16 16"
                                                className="bi bi-chevron-right"
                                                fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                                            </svg>
                                        </Link>
                                    </div>
                                    <div className='pl-0 pr-0 pl-lg-3 pr-lg-3'>
                                        <div className="card-custom-container">
                                            {
                                                highlightList && highlightList.documents && highlightList.documents.length > 0 &&
                                                highlightList.documents.map((itm, key) =>
                                                    <Fragment key={key}>
                                                        {
                                                            key <=2 ?
                                                                <Link
                                                                    to={JSON.parse(getUser()).is_admin ? `/highlights/${itm.id}/edit` : `/highlights/${itm.id}/view`}
                                                                    className="card-custom mt-2 mb-2"
                                                                >
                                                                    <img className="doc-image" src="https://dev.samprofiles.com/images/youtube_icon.png" alt="highlights-icon"/>
                                                                    <p className="doc-image-description f-12">{itm.title}</p>
                                                                </Link>:
                                                                null
                                                        }
                                                    </Fragment>
                                                )
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/*Legal*/}
                            <div className="padding-left-15 border-bottom ml-lg-4 mr-lg-0 mt-lg-0 mb-md-0 ml-2 mr-2 mt-0 mb-0 bg-white">
                                <div className="p-lg-3">
                                    <div className="d-flex justify-content-between">
                                        <h3 className="light-dark f-18 mt-2 mt-lg-0">
                                            Legal
                                            <span className="counter-pill text-center f-12 d-inline-block primary-bg-color text-white">
                                                {legalList && legalList.files && legalList.files.length}
                                            </span>
                                        </h3>
                                        <Link to='/legal' className="text-decoration-none hover-black-color vertical-align-middle primary-color pr-2 pr-lg-0">
                                            more
                                            <svg
                                                width="1em"
                                                height="1em"
                                                viewBox="0 0 16 16"
                                                className="bi bi-chevron-right"
                                                fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg"
                                            >
                                                <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                                            </svg>
                                        </Link>
                                    </div>
                                    <div className='pl-0 pr-0 pl-lg-3 pr-lg-3'>
                                        <div className="card-custom-container">
                                            {
                                                legalList && legalList.files && legalList.files.length > 0 &&
                                                legalList.files.map((itm, key) =>
                                                    <Fragment key={key}>
                                                        {
                                                            key <= 2 ?
                                                                <Link to={`legal/view/${itm.id}`} className="card-custom mt-2 mb-2">
                                                                    <img className="doc-image" src="https://dev.samprofiles.com/images/file.png" alt="legal-icon"/>
                                                                    <p className="doc-image-description f-12">{itm.custom_properties.original_name}</p>
                                                                </Link>:
                                                                null
                                                        }
                                                    </Fragment>    
                                                ) 
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-12 col-lg-4 mt-lg-0 mt-2 pl-lg-0 pd-md-0">
                            <div className="pt-4 pb-3 mr-lg-4 ml-lg-0 mt-lg-4 mb-lg-0 ml-2 mr-2 mt-0 mb-0 bg-white">
                                <h2 className="padding-left-15 f-24">Upcoming</h2>
                            </div>
                            <div className="mr-lg-4 ml-lg-0 mb-lg-0 ml-2 mr-2 mb-0 bg-white">

                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section  align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 1</p>
                                    </div>
                                </div>

                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 2</p>
                                    </div>
                                </div>
                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 3</p>
                                    </div>
                                </div>
                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 4</p>
                                    </div>
                                </div>
                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 5</p>
                                    </div>
                                </div>

                                <div className="parent right-content-bg">
                                    <div className="section primary-bg-color text-white text-center">
                                        <span className="mb-0 f-24">30</span><br/><span className="f-12">Sep</span>
                                    </div>
                                    <div className="section align-self-center">
                                        <p className="mb-0 pl-3 f-18 light-dark">Practice 6</p>
                                    </div>
                                </div>

                                <div className="upcoming-btn-section text-center">
                                    <Link to={'/calendar'} className="text-decoration-none hover-black-color vertical-align-middle primary-color pr-2 pr-lg-0">
                                        more
                                    </Link>
                                </div>
                            </div>

                            <div className="pt-4 pb-3 mr-lg-4 ml-lg-0 mt-lg-4 mb-lg-0 ml-2 mr-2 mt-2 mb-2 bg-white">
                                <h2 className="padding-left-15 f-24">Share your thoughts or <br/> ask anything</h2>

                                <div className="row light-smoked-bg no-gutters mt-4 mb-4 pt-2 pb-2">
                                    <div className="col-9 align-self-center padding-left-15 text-center text-lg-left text-md-left">
                                        <strong className="montserrat-bold f-18">To</strong>{`\u00A0`}{`\u00A0`}
                                        <label className="f-18 mb-0 light-smoked-text">Hassnah Elhage</label>
                                    </div>
                                    <div className="col-3 text-center">
                                        <img className='img-fluid rounded' src='https://dev.samprofiles.com/images/smallimg.jpg' alt='user' />
                                    </div>
                                </div>
                                <div className="p-3 text-lg-right text-center">
                                    <textarea
                                        className="text-area"
                                        placeholder="Write your message..."
                                        cols="5"
                                        rows="5"
                                        name="content"
                                        value={content}
                                        onChange={(e) => setContent(e.target.value)}
                                    />
                                    <button
                                        className="send-btn btn-global border-0 f-14 font-weight-normal"
                                        disabled={content === ''}
                                        onClick={() => {
                                            dispatch(sendMessage(content));
                                            setContent('');
                                        }}
                                    >
                                        Send
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <CreateOrEditGoals
                isCreateOrEditGoalOpen={isCreateOrEditGoalOpen}
                setCreateOrEditGoalOpen={setCreateOrEditGoalOpen}
                idForDashboard={id}
                goalId={goalEditId}
                setGoalId={setEditGoalId}
            />
        </>
    );
};

export default CreateOrEditAthletes;
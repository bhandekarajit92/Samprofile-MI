import React, {useEffect, useState} from 'react';
import validator from 'validator';
import {useDispatch, useSelector} from 'react-redux';
import {useHistory} from 'react-router-dom';
import PropTypes from 'prop-types';

import {Banner, Input, Loader} from '../CommonComponents';
import validateCreateOrEditAthlete from "../../validations/createOrEditAthleteValidation";
import { createOrEditAthletes, getAthleteDetail, resetAthleteDetail } from "../../redux/action";
import {bytesToMegaBytes, mediaUrl} from "../../utils/helper";

const CreateOrEditAthletes = (props) => {
    const [isDragEnterExit, setDragEnterExit] = useState(false);
    const [form, setForm] = useState({
        firstName: '',
        lastName: '',
        address: '',
        postal: '',
        city: '',
        email: '',
        sport: '',
        position: '',
        currentClub: '',
        website: '',
        facebookId: '',
        twitterId: '',
        userImg: ''
    });

    const [errors, setErrors] = useState({});
    const [valid, setValid] = useState({
        firstName: false,
        lastName: false,
        address: false,
        postal: false,
        city: false,
        email: false,
        sport: false,
        position: false,
        currentClub: false,
        website: false,
        facebookId: false,
        twitterId: false,
        userImg: false
    });

    const [img, setImg] = useState(null);
    const [userId, setUserId] = useState(null);

    const dispatch = useDispatch();
    const history = useHistory();

    const loading = useSelector(state => state.Athlete.loading);
    const athleteDetail = useSelector(state => state.Athlete.athleteDetail);

    useEffect(() => {
        if(props.match && props.match.params && props.match.params.id) {
            dispatch(getAthleteDetail(props.match.params.id));
        }
    }, [props, dispatch]);

    useEffect(() => {
        if(athleteDetail) {
            const {address, city, current_club, email, first_name, id, image, last_name, position, postal, sport, facebook_id, twitter_id, website } = athleteDetail;
            setForm({
                firstName: first_name || '',
                lastName: last_name  || '',
                address: address  || '',
                postal: postal  || '',
                city: city  || '',
                email: email  || '',
                sport: sport  || '',
                position: position  || '',
                currentClub: current_club  || '',
                website: website  || '',
                facebookId: facebook_id  || '',
                twitterId: twitter_id  || ''
            });
            setUserId(id);
            if(image) {
                const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
                setImg({
                    file: image,
                    name: image.filename,
                    base64: `${mediaUrl}/avatar/${image.filename}.${image.extension}`,
                    isPreview: acceptedImageTypes.includes(image.mime_type),
                    size: (image.size / (1024 * 1024)).toFixed(2)
                });
            }
        }
    }, [athleteDetail]);

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const getFormattedImage = (file) => {
        const fileReader = new FileReader();
        return new Promise(resolve => {
            fileReader.readAsDataURL(file);
            fileReader.onload = (e) => {
                resolve(e.target.result);
            }
        });
    };

    const handleFileSelect = (e) => {
        if (e.target.files) {
            const file = e.target.files[ 0 ];
            if (!(file.type.split('/')[0] === 'image')) {
                alert('please upload valid image format');
            } else {
                const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
                if(!(bytesToMegaBytes(file.size) > 2)) {
                    setValid({ ...valid, userImg: true });
                    const reader = new FileReader();
                    getFormattedImage(file).then(response => {
                        setImg({
                            file: file,
                            name: file.name,
                            base64: response,
                            isPreview: acceptedImageTypes.includes(file.type),
                            size: (file.size / (1024 * 1024)).toFixed(2)
                        });
                    });
                    reader.readAsDataURL(e.target.files[ 0 ]);
                    setForm({
                        ...form,
                        userImg: e.target.files[ 0 ]
                    });
                } else {
                    alert('please upload file size less 2mb.');
                }
            }
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const { errors, isValid } = validateCreateOrEditAthlete(form);
        setErrors(errors);
        if(isValid){
            dispatch(createOrEditAthletes({
                form,
                callback: () => history.goBack(),
                id: userId
            }));
        }
    };

    return (
        <>
            {loading && <Loader/>}
            <div className='athletes-edit'>
                <Banner
                    title={userId ? 'Edit athlete' : 'Create new athlete'}
                    backText='Athletes'
                    backUrl='/athletes'
                    backClick={() => dispatch(resetAthleteDetail())}
                />
                <div className='card m-3'>
                    <div className="row px-3 py-5">
                        <div className="col-lg-6 col-12 px-5">
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <Input
                                        label='First name'
                                        className={errors.firstName ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='firstName'
                                        value={form.firstName}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, firstName: e.target.value.trim().length >= 3});
                                            setErrors({ ...errors, firstName: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.firstName}
                                        maxLength={20}
                                    />
                                </div>
                                <div className="form-group col-md-6">
                                    <Input
                                        label='Last name'
                                        className={errors.lastName ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='lastName'
                                        value={form.lastName}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, lastName: e.target.value.trim().length >= 3});
                                            setErrors({ ...errors, lastName: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.lastName}
                                        maxLength={20}
                                    />
                                </div>
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Address'
                                    className={errors.address ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='address'
                                    value={form.address}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, address: e.target.value.trim().length >= 3});
                                        setErrors({ ...errors, address: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.address}
                                    maxLength={100}
                                />
                            </div>
                            <div className="form-row">
                                <div className="form-group col-md-6">
                                    <Input
                                        label='Postal'
                                        className={errors.postal ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='postal'
                                        value={form.postal}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, postal: true});
                                            setErrors({ ...errors, postal: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.postal}
                                    />
                                </div>
                                <div className="form-group col-md-6">
                                    <Input
                                        label='City'
                                        className={errors.city ?
                                            'form-control is-invalid' : 'form-control'}
                                        name='city'
                                        value={form.city}
                                        onChange={(e) => {
                                            handleChange(e);
                                            setValid({ ...valid, city: true});
                                            setErrors({ ...errors, city: false });
                                        }}
                                        type='text'
                                        required={true}
                                        errorMsg={errors && errors.city}
                                        maxLength={50}
                                    />
                                </div>
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Email'
                                    className={errors.email ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='email'
                                    value={form.email}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, email: validator.isEmail(e.target.value)});
                                        setErrors({ ...errors, email: false });
                                    }}
                                    type='email'
                                    required={true}
                                    errorMsg={errors && errors.email}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Sport'
                                    className={errors.sport ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='sport'
                                    value={form.sport}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, sport: true});
                                        setErrors({ ...errors, sport: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.sport}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Position'
                                    className={errors.position ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='position'
                                    value={form.position}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, position: true});
                                        setErrors({ ...errors, position: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.position}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Current club'
                                    className={errors.currentClub ?
                                        'form-control is-invalid' : 'form-control'}
                                    name='currentClub'
                                    value={form.currentClub}
                                    onChange={(e) => {
                                        handleChange(e);
                                        setValid({ ...valid, currentClub: true});
                                        setErrors({ ...errors, currentClub: false });
                                    }}
                                    type='text'
                                    required={true}
                                    errorMsg={errors && errors.currentClub}
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Website'
                                    className='form-control'
                                    name='website'
                                    value={form.website}
                                    onChange={handleChange}
                                    type='text'
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                <Input
                                    label='Facebook ID'
                                    className='form-control'
                                    name='facebookId'
                                    value={form.facebookId}
                                    onChange={handleChange}
                                    type='text'
                                    maxLength={50}
                                />
                            </div>
                            <div className="form-group">
                                    <Input
                                        label='Twitter ID'
                                        className='form-control'
                                        name='twitterId'
                                        value={form.twitterId}
                                        onChange={handleChange}
                                        type='text'
                                        maxLength={50}
                                    />
                            </div>
                        </div>
                        <div className="col-lg-6 col-12 px-5">
                            <div className="form-group image">
                                <div>
                                    <label htmlFor='userImg' className='f-14'>
                                        Profile image
                                    </label>
                                </div>
                                <div
                                    className="file-upload"
                                    onDragOver={() => setDragEnterExit(!isDragEnterExit)}
                                    onDragEnd={handleFileSelect}
                                    onChange={(e) => handleFileSelect(e)}
                                >
                                    <input type="file" accept="image/*"/>
                                    <div className="d-flex flex-wrap justify-content-center p-3">
                                        {img &&
                                            <div className="used-area m-3">
                                                {img.isPreview ?
                                                    <div className="bg">
                                                        <button onClick={() => setImg(null)} className="remove">
                                                            <i className='fa fa-close '/>
                                                        </button>
                                                        <img alt={img.name} className="img-fluid preview" src={img.base64}/>
                                                        <div className="overlay">
                                                            <span className="size">{img.size} MB</span>
                                                            <div className="file-name mt-2">
                                                                <span className="name">{img.name}</span>
                                                            </div>
                                                        </div>
                                                    </div> :
                                                    <div className="no-preview">
                                                        <button onClick={() => setImg(null)} className="remove">
                                                            <i className='fa fa-close '/>
                                                        </button>
                                                        <span className="size">{img.size} MB</span>
                                                        <div className="file-name mt-2">
                                                            <span className="name">{img.name}</span>
                                                        </div>
                                                    </div>
                                                }
                                            </div>
                                        }
                                    </div>
                                    {!img && <p>Drop files here or click to upload.</p>}
                                </div>
                                <p className='text-danger mt-2'>Upload only PNG, JPG, JPEG files and Maximum file size is 2 MB.</p>
                            </div>
                        </div>
                    </div>
                    <div className='text-center'>
                        <button
                            className='btn btn-global mx-5 my-3 f-14 cursor-pointer mt-3'
                            onClick={handleSubmit}
                        >
                            {userId ? 'Update athlete' : 'Add athlete'}
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

CreateOrEditAthletes.propTypes = {
    match: PropTypes.shape({
        params: PropTypes.object,
    })
};

export default CreateOrEditAthletes;

import React from 'react';
import PropTypes from 'prop-types';

import {Input} from "../CommonComponents";

const AddBrandingFolder = ({isAddOpen, setAddOpen, setName, name, handleAddFolder, errorMsg, setErrors, errors}) => {
    return (
        <div className={isAddOpen ? "modal fade show d-block" : "d-none"}>
            <div className="modal-dialog modal-dialog-centered" role="document">
                <div className="modal-content">
                    <div className="modal-header border-0">
                        <h5 className="modal-title">Add new folder</h5>
                        <button type="button" className="close" onClick={() => setAddOpen(false)}>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div className='modal-body'>
                        <Input
                            name={name}
                            value={name}
                            type='text'
                            onChange={(e) => {
                                setName(e.target.value);
                                setErrors({ ...errors, name: false })
                            }}
                            placeholder='Folder name'
                            className='form-control'
                            errorMsg={errorMsg}
                        />
                    </div>
                    <div className='text-center p-3'>
                        <button
                            className='btn btn-global'
                            onClick={handleAddFolder}
                        >
                            Create new
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

AddBrandingFolder.propTypes = {
    isAddOpen: PropTypes.bool,
    setAddOpen: PropTypes.func,
    handleAddFolder: PropTypes.func,
    name: PropTypes.string,
    setName: PropTypes.func,
    errorMsg: PropTypes.string
};

export default AddBrandingFolder;
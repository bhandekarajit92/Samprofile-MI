import React, {useState} from 'react';
import PropTypes from 'prop-types';
import {useDispatch} from 'react-redux';

import {mediaUrl} from "../../utils/helper";
import {DeleteConfirmDialog} from "../CommonComponents";
import {deleteFile} from "../../redux/action";

const ShowFile = ({isOpenPopup, setPopupOpen, brandingList,
                      selectedImg, prev, next, handleNextPrev, folder, setImg
                  }) => {
    const name = brandingList &&
        brandingList.all_athletes &&
        brandingList.files &&
        brandingList.files[selectedImg] &&
        brandingList.all_athletes.find(itm =>
            itm.id === brandingList.files[selectedImg].custom_properties.assigned_to
        )
    const [isDeleteOpen, setDeleteOpen] = useState(false);

    const dispatch = useDispatch();

    const handleDeletefile = (value) => {
        dispatch(deleteFile({
            folder,
            id: value,
            callBack: () => {
                setPopupOpen(false);
                setImg('');
                setDeleteOpen(false)
            }
        }))
    }

    return (
        <div className={isOpenPopup ? "modal fade show d-block" : "modal fade"}
             id="exampleModalCenter" tabIndex="-1" role="dialog"
             aria-labelledby="exampleModalCenterTitle" aria-hidden="true"
             style={{overflowY: 'auto'}}
        >
            <div className="modal-dialog modal-dialog-centered  modal-lg" role="document">
                <div className="modal-content">
                    <div className="modal-header border-0">
                        <h5 className="modal-title">
                            {
                                brandingList.files && brandingList.files.length > 0 &&
                                brandingList.files[selectedImg] &&
                                brandingList.files[selectedImg].filename
                            }
                        </h5>
                        <button
                            type="button"
                            className="close"
                            data-dismiss="modal"
                            aria-label="Close"
                            onClick={() => setPopupOpen(false)}
                        >
                            <svg
                                width="1em"
                                height="1em"
                                viewBox="0 0 16 16"
                                className="bi bi-x-circle"
                                fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path fillRule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                <path fillRule="evenodd" d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/>
                            </svg>
                        </button>
                    </div>
                    <div className="modal-body">
                        <div id="carouselExampleControls" className="carousel slide" data-interval="false">
                            {
                                brandingList.files && brandingList.files.length > 0 &&
                                brandingList.files.map((itm, key) =>
                                    <div className="carousel-inner" key={key}>
                                        <div className={key === selectedImg ? "carousel-item active" : "carousel-item"}>
                                            <img
                                                className='img-fluid d-block w-100'
                                                src={folder ?
                                                    `${mediaUrl}branding/${folder}/${itm.custom_properties.original_name}` :
                                                    `${mediaUrl}branding/${itm.custom_properties.original_name}`
                                                }
                                                alt="file"
                                            />
                                        </div>
                                    </div>
                                )
                            }
                            {
                                brandingList &&
                                brandingList.files &&
                                prev !== 0 && <a
                                    className="carousel-control-prev"
                                    href="#carouselExampleControls"
                                    role="button"
                                    data-slide-to={prev}
                                    onClick={() => handleNextPrev('prev')}
                                >
                                    <span className="carousel-control-prev-icon" aria-hidden="true"/>
                                    <span className="sr-only">Previous</span>
                                </a>
                            }
                            {
                                brandingList &&
                                brandingList.files &&
                                next < (brandingList.files.length - 1) && <a
                                    className="carousel-control-next"
                                    href="#carouselExampleControls"
                                    role="button"
                                    data-slide-to={next}
                                    onClick={() => handleNextPrev('next')}
                                >
                                    <span className="carousel-control-next-icon" aria-hidden="true"/>
                                    <span className="sr-only">Next</span>
                                </a>
                            }
                        </div>
                        <p className='pt-2'>Uploaded by: Super User</p>
                        <p>Assign To: {name && `${name.first_name} ${name.last_name}`}</p>
                        <p>Size: {
                            brandingList.files && brandingList.files.length > 0 &&
                            brandingList.files[selectedImg] &&
                            brandingList.files[selectedImg].size
                        } bytes</p>
                        <p className='cursor-pointer text-primary'>
                            <a
                                href={
                                    folder ?
                                        `${mediaUrl}branding/${folder}/${brandingList.files && brandingList.files.length > 0 && 
                                            brandingList.files[selectedImg] && 
                                            brandingList.files[selectedImg].custom_properties.original_name}`:
                                        `${mediaUrl}branding/${brandingList.files && brandingList.files.length > 0 && 
                                        brandingList.files[selectedImg] && 
                                        brandingList.files[selectedImg].custom_properties.original_name}`
                                }
                                target='_blank'
                                rel="noopener noreferrer"
                            >
                                <u>Download</u>
                            </a>
                        </p>
                        <p
                            className='cursor-pointer text-primary'
                            onClick={() => setDeleteOpen(true)}
                        ><u>Delete</u></p>
                    </div>
                </div>
            </div>
            <DeleteConfirmDialog
                isDeleteOpen={isDeleteOpen}
                setDeleteOpen={setDeleteOpen}
                handleDelete={() => handleDeletefile(brandingList.files && brandingList.files.length > 0 &&
                    brandingList.files[selectedImg] &&
                    brandingList.files[selectedImg].id)}
            />
        </div>
    );
};

ShowFile.propTypes = {
    isOpenPopup: PropTypes.bool,
    setPopupOpen: PropTypes.func,
    brandingList: PropTypes.object,
    selectedImg: PropTypes.string,
    prev: PropTypes.string,
    next: PropTypes.string,
    handleNextPrev: PropTypes.func,
    folder: PropTypes.string,
    setImg: PropTypes.func
};

export default ShowFile;
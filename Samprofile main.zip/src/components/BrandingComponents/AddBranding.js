import React, {useEffect, useState} from 'react';
import {useHistory} from "react-router-dom";
import {useDispatch, useSelector} from "react-redux";
import $ from 'jquery';
import {toast} from "react-toastify";

import {Banner, DropDown, Loader} from '../CommonComponents'
import {getAthletesList, createNewMedia} from "../../redux/action";
import {ErrorToast, getFolderLocal} from "../../utils/helper";

const AddBranding = () => {
    const [img, setImg] = useState([]);
    const [athleteId, setAthleteId] = useState(null);
    const [isDragEnterExit, setDragEnterExit] = useState(false);
    const [athleteList, setAthleteList] = useState([]);

    const history = useHistory();
    const dispatch = useDispatch();

    const loading = useSelector(state => state.Branding.loading);
    const loadingAthlete = useSelector(state => state.Athlete.loading);
    const athletesList = useSelector(state => state.Athlete.athletesList);

    useEffect(() => {
        if (athletesList && athletesList.length > 0) {
            setAthleteList(athletesList.map((itm) => {
                return {
                    value: itm.id,
                    name: itm.first_name
                }
            }))
        }
    }, [athletesList]);

    useEffect(() => {
        dispatch(getAthletesList());
    }, [dispatch]);

    useEffect(() => {
        if (img.length > 10) {
            setImg(theArray => theArray.slice(0, 10));
            toast.error(<ErrorToast msg='You can not upload more than 10 files.'/>);
        }
    }, [img]);

    const getFormattedImage = (file) => {
        const fileReader = new FileReader();
        return new Promise(resolve => {
            fileReader.readAsDataURL(file);
            fileReader.onload = (e) => {
                resolve(e.target.result);
            }
        });
    };

    const handleFileSelect = (e) => {
        if (img.length < 10) {
            const files = e.target.files;
            let fileSize = 0;
            if(files.length > 0) {
                for (let i = 0; i < files.length; i++) {
                    fileSize = fileSize + files[i].size;
                }
                if (fileSize > 2097152) {
                    toast.error(<ErrorToast msg='File size must not be more than 2 MB'/>);
                } else {
                    const arrPromise = [];
                    let arr = [];
                    const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png', 'image/jpg'];
                    for (const key in files) {
                        if (files.hasOwnProperty(key)) {
                            arrPromise.push(new Promise(resolve => {
                                getFormattedImage(files[key]).then(response => {
                                    arr.push({
                                        file: files[key],
                                        name: files[key].name,
                                        base64: response,
                                        isPreview: acceptedImageTypes.includes(files[key].type),
                                        size: (files[key].size / (1024 * 1024)).toFixed(2)
                                    });
                                    resolve();
                                });
                            }))
                        }
                    }
                    Promise.all(arrPromise).then(() => {
                        setImg([...img, ...arr]);
                        $('input[type="file"]').val(null);
                    });
                }
            }
        } else {
            toast.error(<ErrorToast msg='You can not upload more than 10 files.' />);
        }
    };

    const handleRemoveFile = (file) => {
        setImg(img => img.filter(item => item.base64 !== file.base64));
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if (athleteId && img.length !== 0) {
            dispatch(createNewMedia({
                id: athleteId,
                files: img.filter(itm => itm.file),
                folder: getFolderLocal(),
                callBack: () => history.push('/branding', {
                    folder: getFolderLocal()
                })
            }))
        }else if (!athleteId) {
            toast.error(<ErrorToast msg='Please select an athlete.'/>)
        }
    }

    return(
        <>
            {(loading || loadingAthlete) && <Loader/>}
            <div className="add-branding">
                <Banner
                    title='Create new media'
                    backText='Branding'
                    backUrl='/branding'
                    backClick={() => {console.log('')}}
                />
                <div className="centerContainer">
                    <div className="filterBox w-100 d-block d-md-flex justify-content-between">
                        <div>
                            <DropDown
                                onselect={(e) => setAthleteId(e.target.value)}
                                dropDownHeading='Attach file to athlete'
                                dropDownSelected='Select athlete'
                                dropDownOption={athleteList}
                                name='athlete'
                            />
                        </div>
                    </div>
                    <div className="folderBox d-block">
                        <div className="col-12">
                            <div className="file-upload" onDragOver={() => setDragEnterExit(!isDragEnterExit)}
                                 onDragEnd={handleFileSelect} onChange={handleFileSelect}>
                                <input type="file" multiple accept="image/*"/>
                                <div className="d-flex  flex-wrap justify-content-center p-3">
                                    {img.map((item, key) =>
                                        <div key={key} className="used-area m-3">
                                            {item.isPreview ?
                                                <div className="bg">
                                                    <button onClick={() => handleRemoveFile(item)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <img alt={item.name} className="img-fluid preview" src={item.base64}/>
                                                    <div className="overlay">
                                                        <span className="size">{item.size} MB</span>
                                                        <div className="file-name mt-2">
                                                            <span className="name">{item.name}</span>
                                                        </div>
                                                    </div>
                                                </div> :
                                                <div className="no-preview">
                                                    <button onClick={() => handleRemoveFile(item)} className="remove">
                                                        <i className='fa fa-close '/>
                                                    </button>
                                                    <span className="size">{item.size} MB</span>
                                                    <div className="file-name mt-2">
                                                        <span className="name">{item.name}</span>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    )}
                                </div>
                                {img.length === 0 ? <p>Drop files here or click to upload.</p> : ''}
                            </div>
                        </div>
                    </div>
                    <div className='text-center'>
                        <button
                            onClick={handleSubmit}
                            className="btn btn-global mt-3 mr-3"
                            disabled={img.length === 0}
                        >
                            Save
                        </button>
                        <button
                            className="btn btn-global mt-3"
                            onClick={() => history.push('/branding', {
                                folder: getFolderLocal()
                            })}
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AddBranding;
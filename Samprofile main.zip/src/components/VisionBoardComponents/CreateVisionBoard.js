import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';

import {Banner, Loader} from "../../components/CommonComponents";
import {getVisionboardList,  uploadVISIONBOARD} from "../../redux/action";
import {mediaUrl} from "../../utils/helper";
import $ from "jquery";

const CreateVisionboard = () => {
    const acceptedImageTypes = ['image/gif', 'image/jpeg', 'image/png'];

    let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

    const dispatch = useDispatch();

    const loading = useSelector(state => state.Visionboard.loading);
    const visionboardList = useSelector(state => state.Visionboard.visionboardList);

    const [isDragEnterExit, setDragEnterExit] = useState(false);

    useEffect(() => {
        $('input[type="file"]').val(null);
    }, [visionboardList]);

    useEffect(() => {
        dispatch(getVisionboardList({
            athlete_id : ''
        }))
    }, [dispatch]);

    const handleFileSelect = (e,i) => {

        if(acceptedImageTypes.includes(e.target.files[0].type)){
            const req = {id: i+1, files: e.target.files};
            dispatch(uploadVISIONBOARD({req,callback: () => dispatch(getVisionboardList({
                    athlete_id : ''
                }))}));
        }else{
            alert('please upload valid image format');
        }
    }

    const grid = (item,key) => {

        let classname = 'gallery__item gallery__item--'+item+' custom-border-dark mb-0';
        return (
            <figure key={key} className={classname} onDragOver={() => setDragEnterExit(!isDragEnterExit)} onDragEnd={($event) => handleFileSelect($event,key)} onChange={($event) => handleFileSelect($event,key)}>
                    <input type="file"  />
                    {visionboardList && visionboardList.visionBoard[key] ?
                        <div className="bg m-3">
                            <img className="img-fluid preview" alt={item} src={`${mediaUrl}visionboard/${visionboardList.visionBoard[key].filename}.${visionboardList.visionBoard[key].extension}`}/>
                            <div className="overlay">
                                <span className="size">{(visionboardList.visionBoard[key].size / Math.pow(1024, 2)).toFixed(2)} MB </span>
                                <div className="file-name mt-2">
                                    <span className="name">{visionboardList.visionBoard[key].filename}.{visionboardList.visionBoard[key].extension}</span>
                                </div>
                            </div>
                        </div>
                        :
                        <p className="small-note">Drop files here or click to upload. </p>
                    }
            </figure>
        )
    }

    return (
        <>
            {loading && <Loader/>}
            <div className="visionboard">
                <Banner
                    isGreen={true}
                    title='Visionboard'
                    RedirectTo={`/visionboard`}
                    buttonText='Save visionboard'
                    backClick={() => console.log('')}
                />
                <div className="container-fluid pl-0 pr-0">
                    <div className="gallery mt-2">
                        {arr.map((item,key)=>grid(item,key))}
                    </div>
                </div>
            </div>
        </>
    );
};

CreateVisionboard.propTypes = {
    match: PropTypes.shape({
        url: PropTypes.string,
    })
};

export default CreateVisionboard;

import validator from 'validator';

function validateCreateOrEditHighlights(data) {
    const errors = {};

    if (validator.isEmpty(data.title.trim())) errors.title = 'The title field is required.';
    else if(!validator.isLength(data.title, {min:3, max: 50})) errors.title = 'Entered title name should be minimum 3 characters and maximum 50 characters.'

    if (validator.isEmpty(data.contents.trim())) errors.contents = 'The contents field is required.';

    if (validator.isEmpty(data.created_for.trim())) errors.created_for = 'The belongs to field is required.';

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateCreateOrEditHighlights;

import validator from 'validator';

function validateAddBrandingFolder(data) {
    const errors = {};

    if (validator.isEmpty(data.name.trim())) errors.name = 'The name field is required.';

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateAddBrandingFolder;
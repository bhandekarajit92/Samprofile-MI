/*Validation for Create or Edit Goal*/
import validator from 'validator';

function validateCreateOrEditGoal(data) {
    const errors = {};

    if (validator.isEmpty(data.title.trim())) errors.title = 'The Goal name field is required.';
    else if(!validator.isLength(data.title, {min:3, max: 30})) errors.title = 'Entered title name should be minimum 3 characters and maximum 30 characters.'

    if (validator.isEmpty(data.due_date)) errors.due_date = 'The Due Date field is required.';

    if (validator.isEmpty(data.start_date)) errors.start_date = 'The Start Date field is required.';
    else if(data.start_date > data.due_date) errors.start_date = 'The start date should not be greater than end date.'

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateCreateOrEditGoal;


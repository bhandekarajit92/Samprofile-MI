import validator from 'validator';

function validateCreateOrEditAthlete(data) {
    const errors = {};
    if (validator.isEmpty(data.firstName.trim())) errors.firstName = 'The first name field is required.';
    else if(!validator.isLength(data.firstName, {min:3, max: 20})) errors.firstName = 'Entered first name should be minimum 3 characters and maximum 20 characters.'

    if (validator.isEmpty(data.lastName.trim())) errors.lastName = 'The last name field is required.';
    else if(!validator.isLength(data.lastName, {min:3, max: 20})) errors.lastName = 'Entered last name should be minimum 3 characters and maximum 20 characters.'

    if (validator.isEmpty(data.address.trim())) errors.address = 'The address field is required.';
    else if(!validator.isLength(data.address, {min:3, max: 100})) errors.address = 'Entered address should be minimum 3 characters and maximum 100 characters.'

    if (validator.isEmpty(data.postal.trim())) errors.postal = 'The postal field is required.';

    if (validator.isEmpty(data.city.trim())) errors.city = 'The city field is required.';

    if (validator.isEmpty(data.sport.trim())) errors.sport = 'The sport field is required.';

    if (validator.isEmpty(data.position.trim())) errors.position = 'The position field is required.';

    if (validator.isEmpty(data.currentClub.trim())) errors.currentClub = 'The current club field is required.';

    if (validator.isEmpty(data.email.trim())) errors.email = 'The email field is required.';
    else if (!validator.isEmail(data.email)) errors.email = 'Please enter valid email address.';

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateCreateOrEditAthlete;
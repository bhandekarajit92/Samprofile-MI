/* Validation file for login */

import validator from 'validator';

function validateLogin(data) {
    const errors = {};

    if (validator.isEmpty(data.email.trim())) errors.email = 'The email field is required.';
    else if (!validator.isEmail(data.email)) errors.email = 'The email must be a valid email address.';

    if (validator.isEmpty(data.password.trim())) errors.password = 'The password field is required.';

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateLogin;
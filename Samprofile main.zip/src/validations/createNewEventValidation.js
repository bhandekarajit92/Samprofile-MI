import validator from "validator";

function createNewEventValidation(data) {
  const errors = {};

  if (validator.isEmpty(data.title.trim()))
    errors.title = "The title field is required";
  else if (!validator.isLength(data.title, { min: 3, max: 20 }))
    errors.title =
      "Entered title should be minimum 3 characters and maximum 20 characters.";

  if (validator.isEmpty(data.location.trim()))
    errors.location = "The location field is required";
  else if (!validator.isLength(data.location, { min: 3, max: 20 }))
    errors.location =
      "Entered location should be minimum 3 characters and maximum 20 characters.";

  if (validator.isEmpty(data.duration.trim()))
    errors.duration = "The duration field is required";

  if (validator.isEmpty(data.availableDate1.trim()))
    errors.availableDate1 = "The date field is required";

    if (validator.isEmpty(data.availableTime1.trim()))
    errors.availableTime1 = "The time field is required";

  return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default createNewEventValidation;

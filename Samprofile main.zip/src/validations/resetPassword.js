/* Validation file for Reset password */

import validator from 'validator';

function validateResetPassword(data) {
    const errors = {};

    if (validator.isEmpty(data.password.trim())) errors.password = 'The password field is required.';
    else if(!validator.isLength(data.password, {min:3, max: 16})) errors.password = 'Entered password should be minimum 3 characters and maximum 16 characters.'

    if (validator.isEmpty(data.confirmPassword.trim())) errors.confirmPassword = 'The confirm password field is required.';
    else if(!validator.equals(data.password, data.confirmPassword)) errors.confirmPassword = 'New password and confirm password doesn’t match.' ;

    return { errors, isValid: Object.keys(errors).length <= 0 };
}

export default validateResetPassword;
import 'bootstrap/dist/css/bootstrap.min.css';

import 'bootstrap-daterangepicker/daterangepicker.css';

import 'font-awesome/css/font-awesome.min.css';

import 'react-toastify/dist/ReactToastify.css';

import './assets/scss/style.scss';
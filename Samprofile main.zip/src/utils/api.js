import axios from 'axios';

import {apiUrl, getToken} from "./helper";

const api = axios.create({
    baseURL: apiUrl
});

api.interceptors.request.use(function (config) {
    config.headers.Authorization = `Bearer ${getToken()}`;
    return config;
}, function (error) {
    return Promise.reject(error);
});

api.interceptors.response.use((response) => {
    return response
}, function (error) {
    if (error.response.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        localStorage.removeItem('folder');
        window.location.href = '/login';
        return Promise.reject(error);
    }
    return Promise.reject(error);
});

export default api;
export default {
  items: [
    {
      name: 'Dashboard',
      url: '/dashboard',
      type: 'athlete'
    },
    {
      name: 'Athletes',
      url: '/athletes',
      type: 'admin'
    },
    {
      name: 'External Users',
      url: '/externals',
      type: 'admin'
    },
    {
      name: 'Goals',
      url: '/goals',
      type: 'both'
    },
    {
      name: 'Highlights',
      url: '/highlights',
      type: 'both'
    },
    {
      name: 'Marketing',
      url: '/marketing',
      type: 'both'
    },
    {
      name: 'Branding',
      url: '/branding',
      type: 'both'
    },
    {
      name: 'Visionboard',
      url: '/visionboard',
      type: 'both'
    },
    {
      name: 'Legal',
      url: '/legal',
      type: 'both'
    },
    {
      name: 'Calender',
      url: '/calender',
      type: 'athlete'
    }
  ]
};
